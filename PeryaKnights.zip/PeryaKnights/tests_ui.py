"""
tests_ui.py
-----------
Checks that every UI screen opens, draws, and handles clicks without error.

    python tests_ui.py

This is the fast "is the UI alive?" test. It opens each screen, draws a few
frames, clicks every button on it, and switches between them - the exact
things that break when a file goes missing or an edit slips. If a screen is
broken, this fails loudly here instead of on the projector.

Every line should print PASS. It runs headless (no window pops up) and takes
only a few seconds.
"""

import os
import sys
import traceback

# run without a real screen or speakers, so no window opens
os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pygame
from config import settings
from game.game_manager import GameManager, GameState

# the rules card would block clicks; turn it off so the test can drive buttons
settings.SHOW_RULES_ON_ENTER = False

pygame.init()
surface = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))

fails = []


def check(name, condition):
    print(("PASS  " if condition else "FAIL  ") + name)
    if not condition:
        fails.append(name)


def step(manager, n=1):
    for _ in range(n):
        manager.update(1 / 60)
        manager.draw(surface)


def click(manager, button):
    """Press and release the mouse on a button, the way a person clicks."""
    pygame.mouse.set_pos(button.rect.center)
    manager.handle_event(pygame.event.Event(
        pygame.MOUSEBUTTONDOWN, button=1, pos=button.rect.center))
    manager.handle_event(pygame.event.Event(
        pygame.MOUSEBUTTONUP, button=1, pos=button.rect.center))
    step(manager, 1)


# every screen the game can show
SCREENS = [
    ("MAIN MENU", GameState.MAIN_MENU),
    ("COLOR ROYALE", GameState.COLOR_ROYALE),
    ("OVER / UNDER", GameState.OVER_UNDER),
    ("LUCKY THREE", GameState.LUCKY_THREE),
    ("BEAT THE HOUSE", GameState.BEAT_HOUSE),
    ("CONSEQUENCE POOL / PARUSAHAN", GameState.CONSEQUENCE_POOL),
    ("BATTLE ROYALE", GameState.BATTLE_ROYALE),
    ("ARCADE DUEL", GameState.ARCADE_DUEL),
    ("SETTINGS", GameState.SETTINGS),
]


def buttons_of(screen):
    """Every screen exposes its buttons a little differently - collect them."""
    found = []
    for attr in ("buttons", "rows", "count_buttons", "color_buttons",
                 "number_buttons", "bet_buttons", "choice_buttons",
                 "level_buttons", "chip_buttons"):
        value = getattr(screen, attr, None)
        if callable(value):
            try:
                value = value()
            except Exception:
                value = None
        if isinstance(value, (list, tuple)):
            found.extend(value)
    for attr in ("place_button", "roll_button", "back_button", "again_button",
                 "start_button", "done_button", "random_button", "lucky_button"):
        b = getattr(screen, attr, None)
        if b is not None:
            found.append(b)
    return found


manager = GameManager(surface)

print("=== every screen opens and draws ===")
for label, state in SCREENS:
    ok = True
    try:
        manager.change_state(state)
        step(manager, 8)                       # draw a few frames
    except Exception:
        ok = False
        traceback.print_exc()
    check("%-18s opens and draws" % label, ok and manager.state == state)

print()
print("=== every button on every screen is clickable ===")
for label, state in SCREENS:
    ok = True
    try:
        manager.change_state(state)
        step(manager, 3)
        for button in buttons_of(manager.current_screen):
            click(manager, button)
            step(manager, 1)
    except Exception:
        ok = False
        traceback.print_exc()
    # after clicking around we may have left the screen (menu buttons do that),
    # which is fine - the point is nothing threw an error
    check("%-18s survives clicking every button" % label, ok)
    manager.change_state(GameState.MAIN_MENU)   # return to a known place

print()
print("=== ESC backs out of every mode to the menu ===")
for label, state in SCREENS[1:]:               # skip the menu itself
    manager.change_state(state)
    step(manager, 3)
    manager.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE))
    step(manager, 3)
    check("%-18s ESC returns to the menu" % label,
          manager.state == GameState.MAIN_MENU)

print()
print("=== switching screens 30 times does not crash or leak ===")
import random
random.seed(1)
ok = True
try:
    for _ in range(30):
        _, state = random.choice(SCREENS)
        manager.change_state(state)
        step(manager, 4)
except Exception:
    ok = False
    traceback.print_exc()
check("rapid screen switching is stable", ok)

print()
if fails:
    print("UI TEST: %d FAILURE(S) -> %s" % (len(fails), fails))
    sys.exit(1)
else:
    print("UI TEST: ALL SCREENS PASSED")
