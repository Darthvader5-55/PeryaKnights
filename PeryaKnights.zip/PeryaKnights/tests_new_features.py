"""
Feature tests for the additions: duel colour trading, player names,
difficulty levels, and the Color Royale extras.

Run it from inside the RiskAndRoll folder:

    python tests_new_features.py
"""
import os, sys, random
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
sys.path.insert(0, os.getcwd())
import pygame
from config import settings
settings.SHOW_RULES_ON_ENTER = False   # drive the buttons directly
from game.game_manager import GameManager, GameState
pygame.init(); surf=pygame.display.set_mode((settings.SCREEN_WIDTH,settings.SCREEN_HEIGHT))
m=GameManager(surf)
def click_at(pos):
    pygame.mouse.set_pos(pos)
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=pos))
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONUP,button=1,pos=pos))
    step(2)
def click(b): click_at(b.rect.center)
def key(k, u=""):
    m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=k,unicode=u)); step(1)
def step(n=1):
    for _ in range(n): m.update(1/60); m.draw(surf)

# ---------- DUEL: choosing colours and dice count ----------
m.change_state(GameState.ARCADE_DUEL); s=m.current_screen
step(3)
def cb(name): return next(b for b in s.color_buttons if b.label==name)
print("duel opens in:", s.phase, "|", s.message)
assert s.phase=="SETUP" and not s.roll_button.enabled
for name in ["ORANGE","RED","PURPLE","BLUE","YELLOW","GREEN"]:
    click(cb(name))
print("drafted      A=%s  B=%s  ready=%s" % (s.duel.team_a, s.duel.team_b, s.phase))
assert s.duel.team_a==["ORANGE","PURPLE","YELLOW"] and s.duel.team_b==["RED","BLUE","GREEN"]
click(cb("ORANGE"))
print("tap again    releases it: A=%s  phase=%s" % (s.duel.team_a, s.phase))
assert s.phase=="SETUP"
click(cb("ORANGE"))
click(s.roll_button)
for i in range(1200):
    step()
    if s.phase=="RESULT": break
r=s.duel.last_result; vals={c:d.value for c,d in s.dice.by_color.items()}
assert r["total_a"]==sum(vals[c] for c in s.duel.team_a)
assert r["total_b"]==sum(vals[c] for c in s.duel.team_b)
print("scoring uses the CHOSEN colours: A=%d B=%d winner %s" % (r["total_a"],r["total_b"],r["winner"]))
click(s.result_panel.primary)

click(s.change_button); click(s.count_buttons[0])
assert s.duel.dice_count==1 and s.duel.team_a==[]
click(cb("BLUE")); click(cb("YELLOW"))
visible=[d.color_name for d in s.dice.dice if d.visible]
print("1 die each   table holds only:", sorted(visible))
assert sorted(visible)==["BLUE","YELLOW"]
click(s.roll_button)
for i in range(1200):
    step()
    if s.phase=="RESULT": break
r=s.duel.last_result
assert 1<=r["total_a"]<=6 and 1<=r["total_b"]<=6
print("1v1 result   A=%d B=%d %s" % (r["total_a"],r["total_b"],r["winner"]))
click(s.result_panel.primary)
click(s.change_button); click(s.count_buttons[1]); click(s.random_button)
print("2v2 random   A=%s B=%s" % (s.duel.team_a, s.duel.team_b))
assert len(s.duel.team_a)==2 and len(s.duel.team_b)==2 and not set(s.duel.team_a)&set(s.duel.team_b)

# ---------- CONSEQUENCE: names + levels ----------
m.change_state(GameState.CONSEQUENCE_POOL); s=m.current_screen
step(3)
click_at(s.name_rows["RED"].center)
for ch in "MARIA": key(pygame.K_a, ch)
key(pygame.K_RETURN)
print("typed name   RED ->", s.player_label("RED"))
assert s.player_label("RED")=="MARIA"
click_at(s.name_rows["BLUE"].center)
for ch in "JOSE": key(pygame.K_a, ch)
key(pygame.K_BACKSPACE); key(pygame.K_RETURN)
print("backspace    BLUE ->", s.player_label("BLUE")); assert s.player_label("BLUE")=="JOS"
click_at(s.name_rows["GREEN"].center)
for ch in "XX": key(pygame.K_a, ch)
key(pygame.K_ESCAPE)
print("escape cancels, GREEN ->", s.player_label("GREEN"), "| still in mode:", m.state)
assert s.player_label("GREEN")=="MANLALARO 3", "ESC should undo the typing"
assert m.state==GameState.CONSEQUENCE_POOL, "ESC while typing must not leave the mode"
click_at(s.name_rows["YELLOW"].center)
for ch in "ABCDEFGHIJKLMNOP": key(pygame.K_a, ch)
key(pygame.K_RETURN)
print("length capped at %d: %s" % (len(s.player_label("YELLOW")), s.player_label("YELLOW")))
assert len(s.player_label("YELLOW"))<=10

print("levels on:", s.book.enabled_names())
click(s.level_buttons[4]); click(s.level_buttons[0])
print("after toggles:", s.book.enabled_names())
for b in s.level_buttons: click(b)
print("cannot switch all off:", s.book.enabled_names()); assert len(s.book.enabled_names())>=1
# lock to one level and check the dare comes from it
for name,b in zip(s.book.category_names(), s.level_buttons):
    if s.book.is_enabled(name) and name!="EKSTREMA": click(b)
if not s.book.is_enabled("EKSTREMA"):
    click(s.level_buttons[4])
for name,b in zip(s.book.category_names(), s.level_buttons):
    if name!="EKSTREMA" and s.book.is_enabled(name): click(b)
print("locked to:", s.book.enabled_names())
click(s.roll_button)
for i in range(1800):
    step()
    if s.phase=="RESULT": break
print("loser %s -> %s" % (s.result_panel.lines[0][1], s.result_panel.big_note))
assert s.result_panel.lines[0][1] in [s.player_label(c) for c in s.active_colors]
assert s.result_panel.big_note in s.book.categories["EKSTREMA"]["items"], "dare came from a disabled level"
print("dare came from the only enabled level: OK")
print("\n--- COLOR ROYALE EXTRAS ---")
m.change_state(GameState.COLOR_ROYALE); s=m.current_screen; step(3)

# keyboard shortcuts
key(pygame.K_w); key(pygame.K_4)
print("keys W + 4 ->", s.betting.color, s.betting.number)
assert (s.betting.color, s.betting.number) == ("BLUE", 4)
key(pygame.K_e); key(pygame.K_6)
print("keys E + 6 ->", s.betting.color, s.betting.number)

# lucky pick
key(pygame.K_l)
print("lucky pick ->", s.betting.color, s.betting.number, s.betting.amount)
assert s.betting.is_complete and s.betting.amount <= s.betting.credits

# play 25 rounds and watch the extras
random.seed(2)
resets = 0
for i in range(25):
    if not s.betting.can_afford_anything():
        key(pygame.K_r); resets += 1
    key(pygame.K_l)
    key(pygame.K_SPACE)
    for f in range(900):
        step()
        if s.phase=="RESULT": break
    else: raise AssertionError("round stalled")
    key(pygame.K_SPACE)   # play again
print("25 rounds via keyboard only: ok")
print("resets during the run:", resets)
print("history holds %d entries (cap %d)" % (len(s.history.entries), s.history.limit))
assert len(s.history.entries) == min(25, s.history.limit), "history should survive a credit reset"
st = s.streaks
print("streaks: rounds=%d wins=%d rate=%d%% best=%d worst=%d biggest win=%d"
      % (st.rounds, st.wins, st.win_rate(), st.best_win_streak, st.worst_loss_streak, st.biggest_win))
assert st.rounds + 0 <= 25 and st.wins <= st.rounds
print("streak label:", st.label())

# confetti only on a win, and it clears itself
s.confetti.burst((640,360), 60)
print("confetti pieces:", len(s.confetti.pieces))
for _ in range(240): s.confetti.update(1/60)
print("after 4s ->", len(s.confetti.pieces), "(should be 0)")
assert not s.confetti.active

# reset clears everything
key(pygame.K_r)
print("after R: credits=%d, streak rounds=%d (reset), history kept=%d"
      % (s.betting.credits, s.streaks.rounds, len(s.history.entries)))
assert s.betting.credits == settings.STARTING_CREDITS
assert s.streaks.rounds == 0, "streaks belong to the player and should reset"
assert s.history.entries, "history belongs to the machine and should survive"
print("\nALL NEW FEATURES: CHECKS PASSED")

