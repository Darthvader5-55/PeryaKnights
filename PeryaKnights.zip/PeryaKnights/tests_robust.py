"""
tests_robust.py
---------------
Checks the game does NOT crash when things go wrong - the difference between
"works when everything is perfect" and "will not die on the projector".

    python tests_robust.py

A demo laptop is a messy place: a config file gets corrupted, there is no
sound card, someone mashes every button, a lag spike hits. A good program
survives all of it. This test deliberately breaks things and checks the game
keeps running:

  1. a corrupt consequences.json falls back to built-in dares
  2. a missing consequences.json falls back too
  3. all difficulty levels switched off still gives a dare
  4. no sound card - the game runs silent, never crashes
  5. mashing every button for hundreds of frames breaks nothing
  6. a long session of many rounds does not error or leak

It restores every file it touches. Every line prints PASS.
"""

import os
import sys
import json
import shutil

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import random
import pygame
from config import settings

settings.SHOW_RULES_ON_ENTER = False

pygame.init()
surface = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))

fails = []


def check(name, condition):
    print(("PASS  " if condition else "FAIL  ") + name)
    if not condition:
        fails.append(name)


# ===========================================================================
# 1-3. broken / missing / all-off consequences.json
# ===========================================================================
print("=== the dares file survives being broken ===")
from game.consequences import ConsequenceBook

path = settings.CONSEQUENCES_FILE
good = open(path, encoding="utf-8").read()      # keep the real file to restore

try:
    # corrupt it with junk
    open(path, "w", encoding="utf-8").write("{ this is not valid json ,,,")
    book = ConsequenceBook()
    _cat, dare = book.random_consequence()
    check("corrupt json falls back, still gives a dare",
          book.load_error is not None and bool(dare))

    # remove it entirely
    os.rename(path, path + ".hidden")
    book = ConsequenceBook()
    _cat, dare = book.random_consequence()
    check("missing file falls back, still gives a dare",
          book.load_error is not None and bool(dare))
    os.rename(path + ".hidden", path)

    # a valid file but every level switched off
    data = json.loads(good)
    for entry in data["categories"].values():
        entry["enabled"] = False
    open(path, "w", encoding="utf-8").write(json.dumps(data))
    book = ConsequenceBook()
    _cat, dare = book.random_consequence()
    check("all levels off still produces a dare", bool(dare))
finally:
    open(path, "w", encoding="utf-8").write(good)     # always restore
    book = ConsequenceBook()
    check("the real dares file loads cleanly again", book.load_error is None)


# ===========================================================================
# 4. no sound card - the game must run silent, not crash
# ===========================================================================
print()
print("=== the game runs even with no sound at all ===")
from game.audio import Audio

# force the mixer to fail, the way a machine with no audio device would
real_init = pygame.mixer.init
def boom(*a, **k):
    raise pygame.error("no audio device")
pygame.mixer.init = boom
try:
    silent = Audio()
    # every sound call must be safe even though audio is dead
    for name in ("click", "place", "win", "lose", "beep"):
        silent.play(name)
    silent.start_music()
    silent.toggle_mute()
    check("audio with no sound card is disabled, not crashed",
          silent.enabled is False)
    check("playing sounds with no audio never errors", True)
finally:
    pygame.mixer.init = real_init


# ===========================================================================
# 5. mashing every button breaks nothing
# ===========================================================================
print()
print("=== mashing every button in every mode is safe ===")
from game.game_manager import GameManager, GameState

manager = GameManager(surface)


def click(button):
    pygame.mouse.set_pos(button.rect.center)
    manager.handle_event(pygame.event.Event(
        pygame.MOUSEBUTTONDOWN, button=1, pos=button.rect.center))
    manager.handle_event(pygame.event.Event(
        pygame.MOUSEBUTTONUP, button=1, pos=button.rect.center))


def all_buttons(screen):
    found = []
    for attr in ("buttons", "rows", "count_buttons", "color_buttons",
                 "number_buttons", "bet_buttons", "choice_buttons",
                 "level_buttons", "chip_buttons"):
        v = getattr(screen, attr, None)
        if callable(v):
            try:
                v = v()
            except Exception:
                v = None
        if isinstance(v, (list, tuple)):
            found.extend(v)
    for attr in ("place_button", "roll_button", "back_button", "again_button",
                 "start_button", "done_button", "random_button"):
        b = getattr(screen, attr, None)
        if b is not None:
            found.append(b)
    return found


import traceback
mash_ok = True
try:
    for state in (GameState.COLOR_ROYALE, GameState.OVER_UNDER,
                  GameState.LUCKY_THREE, GameState.BEAT_HOUSE,
                  GameState.CONSEQUENCE_POOL, GameState.BATTLE_ROYALE,
                  GameState.ARCADE_DUEL):
        manager.change_state(state)
        for _ in range(80):
            for b in all_buttons(manager.current_screen):
                click(b)
            manager.update(1 / 60)
            manager.draw(surface)
        manager.change_state(GameState.MAIN_MENU)
except Exception:
    mash_ok = False
    traceback.print_exc()
check("hundreds of frames of mashing every button is safe", mash_ok)


# ===========================================================================
# 6. a long session does not error or leak unboundedly
# ===========================================================================
print()
print("=== a long booth session stays stable ===")
import ui.ui as U
import game.dice as D

random.seed(3)
long_ok = True
rounds = 0
try:
    for _ in range(8):
        manager.change_state(random.choice([
            GameState.COLOR_ROYALE, GameState.CONSEQUENCE_POOL,
            GameState.ARCADE_DUEL]))
        s = manager.current_screen
        for _ in range(4):
            for attr in ("roll_button", "place_button"):
                b = getattr(s, attr, None)
                if b:
                    if hasattr(s, "betting") and not s.betting.can_afford_anything():
                        s.betting.reset_credits()
                    if hasattr(s, "random_button") and getattr(s, "random_button"):
                        click(s.random_button)
                    click(b)
                    break
            for _ in range(1500):
                manager.update(1 / 60)
                manager.draw(surface)
                if getattr(s, "phase", "") == "RESULT":
                    break
            rounds += 1
            for attr in ("again_button",):
                b = getattr(s, attr, None)
                if b and getattr(s, "result_panel", None) \
                        and s.result_panel.visible:
                    click(s.result_panel.primary)
except Exception:
    long_ok = False
    traceback.print_exc()
check("a long session of many rounds does not crash", long_ok)
# the caches are meant to stay bounded, not grow forever
check("the picture caches stay a sane size (not leaking)",
      len(U._text_cache) < 1000 and len(D._die_cache) < 500)


print()
if fails:
    print("ROBUSTNESS TEST: %d FAILURE(S) -> %s" % (len(fails), fails))
    sys.exit(1)
else:
    print("ROBUSTNESS TEST: THE GAME SURVIVES EVERYTHING THROWN AT IT")
