"""
check_music.py
--------------
Tells you why your background music is or is not playing.

    python check_music.py

It looks in assets/sounds/, lists what it finds, and points out the exact
problem - almost always a filename typo or a format the phone cannot read.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import settings

folder = settings.SOUND_DIR
print("Looking in:", folder)
print()

if not os.path.isdir(folder):
    print("That folder does not exist. Something is wrong with the game copy.")
    raise SystemExit(1)

# what the game actually searches for, in order
WANTED = ["music.ogg", "music.mp3", "music.wav",
          "background.ogg", "background.mp3"]

files = sorted(os.listdir(folder))
print("Files currently in that folder:")
if files:
    for name in files:
        print("   ", name)
else:
    print("    (empty)")
print()

# is one of the accepted names there?
found = None
for name in WANTED:
    if name in files:
        found = name
        break

if found:
    print("FOUND:", found, "- the game will try to play this.")
    print()
    print("If it still does not play, the file itself may be the problem:")
    print("  - a renamed .mp4 or video is not real music, even if the name is right")
    print("  - some .mp3 files use a format pygame cannot read; convert to .ogg")
    print("  - check the SOUND row in SETTINGS is not muted")
    print("  - check MUSIC_VOLUME in config/settings.py is not 0")
    # try to actually load it
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    import pygame
    pygame.init()
    try:
        pygame.mixer.init()
        pygame.mixer.music.load(os.path.join(folder, found))
        print()
        print("  -> pygame CAN load this file. It should play in the game.")
    except pygame.error as error:
        print()
        print("  -> pygame CANNOT load this file:")
        print("     ", error)
        print("     Convert it to .ogg (try an online 'mp3 to ogg' converter)")
        print("     and name the result music.ogg")
else:
    print("PROBLEM: no file with an accepted name is here.")
    print()
    print("The game only plays a file named EXACTLY one of these:")
    for name in WANTED:
        print("   ", name)
    print()
    # look for near-misses to help
    for name in files:
        low = name.lower()
        if "music" in low or "background" in low or low.endswith(
                (".ogg", ".mp3", ".wav", ".m4a", ".mp4")):
            print("You have '%s' - rename it to 'music.ogg' (or music.mp3/.wav)." % name)
            break
    else:
        print("Put your music file here and rename it to music.ogg")
