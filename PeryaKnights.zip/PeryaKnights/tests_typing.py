"""
Tests that typing a name never fires a keyboard shortcut.

    python tests_typing.py

The bug this exists to catch: a player typing SETH into a name box pressed H,
which was the HOW TO PLAY shortcut, so the rules card opened instead of the
letter appearing. Names full of shortcut letters are tried here on purpose.
"""
import os, sys
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
sys.path.insert(0, os.getcwd())
import pygame
from config import settings
settings.SHOW_RULES_ON_ENTER = False
from game.game_manager import GameManager, GameState
pygame.init(); surf=pygame.display.set_mode((settings.SCREEN_WIDTH,settings.SCREEN_HEIGHT))
m=GameManager(surf)
def step(n=1):
    for _ in range(n): m.update(1/60); m.draw(surf)
def click_at(pos):
    pygame.mouse.set_pos(pos)
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=pos))
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONUP,button=1,pos=pos)); step(2)
def typ(ch):
    m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_a,unicode=ch)); step(1)
def key(k):
    m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=k,unicode="")); step(1)

# every letter that is also a shortcut somewhere in the game
TRICKY = ["SETH", "HANNAH", "RHEA", "LORD", "CHRIS", "DEN", "HUGH", "ULRICH"]

for state, rows_attr in ((GameState.BATTLE_ROYALE, "name_rows"),
                         (GameState.CONSEQUENCE_POOL, "name_rows")):
    m.change_state(state); s=m.current_screen; step(3)
    colours = list(s.name_rows.keys()) if s.name_rows else []
    if not colours:
        step(3); colours = list(s.name_rows.keys())
    for index, name in enumerate(TRICKY[:len(colours)]):
        colour = colours[index]
        click_at(s.name_rows[colour].center)
        assert s.is_typing(), "%s did not enter typing mode" % state
        for ch in name:
            typ(ch)
        key(pygame.K_RETURN)
        got = s.label_for(colour) if hasattr(s, "label_for") else s.player_label(colour)
        assert got == name, "%s: typed %s but got %s" % (state, name, got)
        assert not s.help_panel.visible, "the rules card opened while typing %s" % name
    print("%-18s typed %s - every letter landed, no rules card"
          % (state, ", ".join(TRICKY[:len(colours)])))

# H must still work normally when NOT typing
m.change_state(GameState.BATTLE_ROYALE); s=m.current_screen; step(3)
assert not s.is_typing()
key(pygame.K_h)
assert s.help_panel.visible, "H no longer opens the rules when not typing"
print("H still opens HOW TO PLAY when no name box is open")
key(pygame.K_ESCAPE)
assert not s.help_panel.visible

# and the other modes are unaffected
for state in (GameState.COLOR_ROYALE, GameState.LUCKY_THREE, GameState.OVER_UNDER,
              GameState.BEAT_HOUSE, GameState.ARCADE_DUEL):
    m.change_state(state); s=m.current_screen; step(3)
    key(pygame.K_h)
    assert s.help_panel.visible, "H stopped working in %s" % state
    key(pygame.K_ESCAPE)
print("H still works in all five modes without name boxes")
print("\nTYPING vs SHORTCUTS: ALL CHECKS PASSED")
