"""
Playthrough tests: drives every screen through real rounds.

Run it from inside the RiskAndRoll folder:

    python tests_playthrough.py

Every line should say PASS. Handy right before a demo.
"""

import os, sys, random, traceback
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
sys.path.insert(0, os.getcwd())
import pygame
from config import settings
settings.SHOW_RULES_ON_ENTER = False   # drive the buttons directly
from game.game_manager import GameManager, GameState

pygame.init()
surf = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
m = GameManager(surf)
DT = 1/60

def click(btn, settle=2):
    """Click a button the way a person does: press, release, then let the
    game run a couple of frames before the next action."""
    pygame.mouse.set_pos(btn.rect.center)
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=btn.rect.center))
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONUP, button=1, pos=btn.rect.center))
    for _ in range(settle):
        m.update(DT); m.draw(surf)

def step(n=1):
    for _ in range(n):
        m.update(DT); m.draw(surf)

def run_frames_until(cond, limit=900, label=""):
    for i in range(limit):
        step()
        if cond(): return i
    raise AssertionError("TIMEOUT waiting for %s after %d frames" % (label, limit))

errors = []
random.seed(11)

# ================= COLOR ROYALE : 40 full rounds =================
m.change_state(GameState.COLOR_ROYALE)
scr = m.current_screen
starting = m.credits
wins = losses = 0
for round_no in range(40):
    if not scr.betting.can_afford_anything():
        scr.betting.reset_credits()
    # pick random valid options through the real buttons
    click(random.choice(scr.color_buttons))
    click(random.choice(scr.number_buttons))
    affordable = [b for b in scr.bet_buttons if int(b.label) <= scr.betting.credits]
    click(random.choice(affordable))
    before = scr.betting.credits
    click(scr.place_button)
    assert scr.phase != "BETTING", "bet did not lock (round %d)" % round_no
    assert scr.betting.credits == before - scr.betting.amount, "stake not deducted"
    run_frames_until(lambda: scr.phase == "RESULT", 900, "result")
    res = scr.betting.last_result
    # the dice on screen must equal the numbers the money used
    shown = {c: d.value for c, d in scr.dice.by_color.items()}
    assert shown == res["results"], "SCREEN/RESULT MISMATCH %s vs %s" % (shown, res["results"])
    assert scr.betting.credits >= 0, "negative credits"
    wins += res["won"]; losses += not res["won"]
    click(scr.result_panel.primary)
    assert scr.phase == "BETTING"
print("COLOR ROYALE : 40 rounds ok   wins=%d losses=%d  credits=%d" % (wins, losses, scr.betting.credits))

# Spam-click protection: hammer every button in every phase. MAIN MENU is one
# of those buttons, so this can legitimately leave the mode - the point of the
# test is that nothing crashes and the game stays in a valid state.
click(scr.color_buttons[0]); click(scr.number_buttons[0]); click(scr.bet_buttons[0])
click(scr.place_button)
for _ in range(300):
    for b in scr.buttons(): click(b, settle=0)
    step()
assert m.state in (GameState.COLOR_ROYALE, GameState.MAIN_MENU), \
    "spam clicking left the game in a strange state: %s" % m.state
print("COLOR ROYALE : survived 300 frames of clicking every button (ended in %s)"
      % m.state)

# start clean again and check an unaffordable bet is refused
m.change_state(GameState.COLOR_ROYALE)
scr = m.current_screen
step(2)
scr.betting.credits = 5
click(scr.color_buttons[0]); click(scr.number_buttons[0]); click(scr.bet_buttons[-1])
click(scr.place_button)
assert scr.phase == "BETTING", "allowed an unaffordable bet"
print("COLOR ROYALE : unaffordable bet correctly refused (%s)" % scr.message)
scr.betting.reset_credits()

# ================= CONSEQUENCE POOL : all player counts =================
for count in range(1, 7):
    m.change_state(GameState.CONSEQUENCE_POOL)
    scr = m.current_screen
    for b in scr.count_buttons:
        if b.label == str(count): click(b)
    click(scr.roll_button)
    frames = run_frames_until(lambda: scr.phase == "RESULT", 1800, "consequence result %d" % count)
    assert scr.loser is not None, "no loser chosen for %d players" % count
    assert scr.result_panel.big_note, "no consequence text"
    print("CONSEQUENCE  : %d players -> loser %-6s after %d sudden-death round(s), %.1fs"
          % (count, scr.loser, scr.round_number, frames/60))

# forced tie -> sudden death must resolve
m.change_state(GameState.CONSEQUENCE_POOL)
scr = m.current_screen
for b in scr.count_buttons:
    if b.label == '4': click(b)
for attempt in range(60):
    click(scr.roll_button)
    run_frames_until(lambda: scr.phase == "RESULT", 1800, "tie test")
    if scr.round_number > 0:
        print("CONSEQUENCE  : sudden death exercised (%d extra round(s)), loser %s"
              % (scr.round_number, scr.loser))
        break
    click(scr.result_panel.primary)
else:
    print("CONSEQUENCE  : no natural tie in 60 tries (fine, logic unit-tested)")

# ================= ARCADE DUEL : 25 duels =================
m.change_state(GameState.ARCADE_DUEL)
scr = m.current_screen
ties = 0
click(scr.random_button)          # both players' colours dealt at random
assert scr.phase == "READY", "duel should be ready once colours are picked"
for i in range(25):
    click(scr.roll_button)
    run_frames_until(lambda: scr.phase == "RESULT", 1200, "duel result")
    r = scr.duel.last_result
    shown = {c: d.value for c, d in scr.dice.by_color.items()}
    # the totals must follow the colours the players actually chose
    assert r["total_a"] == sum(shown[c] for c in scr.duel.team_a), "duel A total wrong"
    assert r["total_b"] == sum(shown[c] for c in scr.duel.team_b), "duel B total wrong"
    ties += (r["winner"] == "TIE")
    click(scr.result_panel.primary)
print("ARCADE DUEL  : 25 duels ok, %d rematches, score %s" % (ties, scr.duel.wins))

# ================= SETTINGS + navigation =================
m.change_state(GameState.SETTINGS)
scr = m.current_screen
for _ in range(3):
    for b in (scr.rows + [scr.back_button]): click(b); step()
print("SETTINGS     : all controls clicked without error")

# every menu route, forwards and back, twice
m.change_state(GameState.MAIN_MENU)
for _ in range(2):
    for i in range(4):
        menu = m.current_screen
        click(menu.buttons[i]); step(3)
        m.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE)); step(3)
        assert m.state == GameState.MAIN_MENU, "ESC did not return to menu from button %d" % i
print("NAVIGATION   : every mode entered and exited twice")

# ================= performance =================
import time
for state in (GameState.MAIN_MENU, GameState.COLOR_ROYALE, GameState.CONSEQUENCE_POOL, GameState.ARCADE_DUEL):
    m.change_state(state)
    if hasattr(m.current_screen, "roll_button"): click(m.current_screen.roll_button)
    step(10)
    t0 = time.time(); step(120); el = time.time()-t0
    print("PERF         : %-17s %5.0f fps possible" % (state, 120/el))

print("\nINTEGRATION: ALL CHECKS PASSED")
