"""User interface package (screens and widgets)."""
