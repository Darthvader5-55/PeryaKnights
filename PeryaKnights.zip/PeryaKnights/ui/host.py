"""ui/host.py
----------------
A tiny animated perya host that gives the booth a funny, barkada-style voice.
No image asset is required: the host is drawn from simple Pygame shapes so the
project stays self-contained.
"""

import math
import pygame

from config import settings
from ui import ui


HOST_LINES = {
    "default": [
        "GORA NA, BOSS! 🎲",
        "TAYA NA! WAG MAHIYA 😎",
        "SWERTEHAN LANG, MGA BOSS!",
        "ISA PA? BAKIT HINDI 😂",
    ],
    "win": [
        "PANALO KA, BOSS! 🔥",
        "AY GRABE, SWERTE! 💸",
        "MAY PAMBAON KA NA! 😎",
    ],
    "jackpot": [
        "JACKPOT?! GRABE KA! 💰",
        "ALL IN ANG SWERTE! 🔥",
        "AYAN! MAY PA-CONGRATS! 🎉",
    ],
    "lose": [
        "ARAY KO PO 😭",
        "SAYANG, BOSS! BAWI NEXT!",
        "DICE, ANO BA 😭",
    ],
    "tie": [
        "PANTAY?! ULITAN! 😂",
        "WALANG AATRAS!",
        "REMATCH NA, MGA BOSS!",
    ],
}


class PeryaHost:
    """Small speech bubble + mascot with gentle idle animation."""

    def __init__(self):
        self.text = ""
        self.kind = "default"
        self.timer = 0.0
        self.life = 0.0
        self.cooldown = 0.0
        self.index = 0
        self.bounce = 0.0

    def say(self, text=None, kind="default", duration=3.0, force=False):
        if not settings.HOST_ENABLED:
            return
        if self.cooldown > 0 and not force:
            return
        if text is None:
            choices = HOST_LINES.get(kind, HOST_LINES["default"])
            text = choices[self.index % len(choices)]
            self.index += 1
        self.text = text
        self.kind = kind
        self.timer = 0.0
        self.life = duration
        self.cooldown = 0.8

    def update(self, dt):
        self.timer += dt
        self.cooldown = max(0.0, self.cooldown - dt)
        self.bounce += dt * 4.0
        if self.life > 0:
            self.life -= dt
            if self.life <= 0:
                self.text = ""

    def draw(self, surface, anchor):
        if not settings.HOST_ENABLED or not self.text:
            return

        x, y = anchor
        # Keep the host compact so it never covers the betting panel.
        bob = int(math.sin(self.bounce) * 2)
        mascot = pygame.Rect(x, y + bob, 42, 42)
        pygame.draw.circle(surface, settings.PAROL_GOLD, mascot.center, 20)
        pygame.draw.circle(surface, settings.WOOD_DARK, mascot.center, 20, 2)
        # simple fiesta hat
        pygame.draw.polygon(surface, settings.PH_RED,
                            [(x - 16, y + bob - 8), (x + 16, y + bob - 8),
                             (x + 9, y + bob - 17), (x - 9, y + bob - 17)])
        pygame.draw.circle(surface, settings.WOOD_DARK, (x - 7, y + bob), 2)
        pygame.draw.circle(surface, settings.WOOD_DARK, (x + 7, y + bob), 2)
        pygame.draw.arc(surface, settings.WOOD_DARK,
                        (x - 10, y + bob + 1, 20, 13), 0.2, 2.9, 2)

        # speech bubble
        bubble = pygame.Rect(x + 30, y - 8 + bob, 260, 58)
        ui.draw_panel(surface, bubble, radius=14,
                      glow_color=settings.GOLD, screws=False)
        pygame.draw.polygon(surface, settings.PANEL_FILL,
                            [(x + 35, y + 27 + bob),
                             (x + 20, y + 35 + bob),
                             (x + 35, y + 40 + bob)])
        pygame.draw.polygon(surface, settings.BRASS,
                            [(x + 35, y + 27 + bob),
                             (x + 20, y + 35 + bob),
                             (x + 35, y + 40 + bob)], 1)

        alpha = int(255 * min(1.0, self.timer * 8))
        text = ui.render_text(self.text, 15, settings.TEXT_BRIGHT, True).copy()
        text.set_alpha(alpha)
        surface.blit(text, text.get_rect(center=(bubble.centerx, bubble.centery)))
