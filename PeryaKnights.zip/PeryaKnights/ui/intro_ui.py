"""
ui/intro_ui.py
---------------
The very first thing the player sees, before the main menu.

The design document's "game story" requirement is answered here: a single
screen that frames the whole game as one night at a barangay perya, in
Tagalog, before the player ever sees a menu or a bet. It reuses the same
ArcadeScene as everywhere else, so the story does not feel like a separate
loading screen bolted onto the front - it is the same room, just empty,
before the lights and the crowd arrive.

Any key, a click, or ENTER moves on to the main menu. It only ever shows
once per launch - GameManager starts here and then never returns.
"""

import pygame

from config import settings
from game.game_manager import Screen, GameState
from ui import ui
from ui.scene import ArcadeScene

STORY_LINES = [
    "Bawat taon, dumarating ang perya sa barangay -",
    "mga ilaw, mga tunog, at mga taong naghahanap ng swerte.",
    "Ngayong gabi, ikaw ang bahala sa gulong at sa mga dais.",
    "Kaya mong basahin ang swerte? Handa ka na bang tumaya?",
]


class IntroUI(Screen):

    def __init__(self, manager):
        super().__init__(manager)
        self.scene = ArcadeScene(dust_count=22)
        self.time = 0.0
        self.card_in = 0.0        # 0..1, the story card sliding/fading in
        self.advanced = False     # guards against double-triggering the move on

    # ------------------------------------------------------------ input ---
    def handle_event(self, event):
        if self.advanced:
            return
        if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
            self._advance()

    def _advance(self):
        self.advanced = True
        self.manager.change_state(GameState.MAIN_MENU)

    # ----------------------------------------------------------- update ---
    def update(self, dt):
        self.time += dt
        self.scene.update(dt)
        self.card_in = min(1.0, self.card_in + dt * 1.4)

    # ------------------------------------------------------------- draw ---
    def draw(self, surface):
        self.scene.draw_back(surface)
        self.scene.draw_front(surface)

        eased = 1 - (1 - self.card_in) ** 3   # ease-out, so it settles gently
        card_w, card_h = 900, 460
        card = pygame.Rect(0, 0, card_w, card_h)
        card.center = (settings.SCREEN_WIDTH // 2,
                       int(settings.SCREEN_HEIGHT * 0.5 + (1 - eased) * 40))

        shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        shade.fill((10, 6, 14, int(140 * eased)))
        surface.blit(shade, (0, 0))

        panel = pygame.Surface(card.size, pygame.SRCALPHA)
        panel.set_alpha(int(255 * eased))
        ui.draw_panel(panel, panel.get_rect(), radius=22)
        surface.blit(panel, card.topleft)

        ui.draw_glow_text(surface, "PERYA KNIGHTS", (card.centerx, card.top + 66),
                          size=54, color=settings.NEON_CYAN, align="center", glow=10)
        ui.draw_text(surface, "ISANG GABI SA PERYA", (card.centerx, card.top + 108),
                     size=16, color=settings.TEXT_DIM, bold=True, align="center")
        ui.draw_divider(surface, (card.centerx, card.top + 130), width=220,
                        color=settings.NEON_PINK)

        line_y = card.top + 178
        for line in STORY_LINES:
            ui.draw_text(surface, line, (card.centerx, line_y), size=21,
                         color=settings.TEXT_BRIGHT, align="center")
            line_y += 34

        hint_alpha = ui.pulse(1.1, 0.4, 1.0)
        hint_color = ui.shade(settings.GOLD, hint_alpha)
        ui.draw_text(surface, "PRESS ANY KEY PARA GORA!",
                     (card.centerx, card.bottom - 34), size=17,
                     color=hint_color, bold=True, align="center")
