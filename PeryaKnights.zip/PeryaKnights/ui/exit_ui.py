"""
ui/exit_ui.py
--------------
The last thing the player sees, bookending ui/intro_ui.py.

GameManager.request_quit() (what EXIT and ESC on the main menu call) comes
here instead of closing the window straight away. After a short farewell -
or the first key/click, for anyone in a hurry - it calls manager.quit_game()
itself, which is the only thing that actually stops the game loop.
"""

import pygame

from config import settings
from game.game_manager import Screen
from ui import ui
from ui.scene import ArcadeScene

HOLD_SECONDS = 2.6     # closes on its own after this long, if nobody moves


class ExitUI(Screen):

    def __init__(self, manager):
        super().__init__(manager)
        self.scene = ArcadeScene(dust_count=22)
        self.time = 0.0
        self.card_in = 0.0
        self.done = False

    def on_enter(self):
        self.manager.audio.stop_music()
        self.manager.audio.play("place")

    # ------------------------------------------------------------ input ---
    def handle_event(self, event):
        if self.done:
            return
        if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
            self._finish()

    def _finish(self):
        self.done = True
        self.manager.quit_game()

    # ----------------------------------------------------------- update ---
    def update(self, dt):
        self.time += dt
        self.scene.update(dt)
        self.card_in = min(1.0, self.card_in + dt * 1.4)
        if self.time >= HOLD_SECONDS and not self.done:
            self._finish()

    # ------------------------------------------------------------- draw ---
    def draw(self, surface):
        self.scene.draw_back(surface)
        self.scene.draw_front(surface)

        eased = 1 - (1 - self.card_in) ** 3
        card_w, card_h = 820, 340
        card = pygame.Rect(0, 0, card_w, card_h)
        card.center = (settings.SCREEN_WIDTH // 2,
                       int(settings.SCREEN_HEIGHT * 0.5 - (1 - eased) * 30))

        shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        shade.fill((10, 6, 14, int(160 * eased)))
        surface.blit(shade, (0, 0))

        panel = pygame.Surface(card.size, pygame.SRCALPHA)
        panel.set_alpha(int(255 * eased))
        ui.draw_panel(panel, panel.get_rect(), radius=22)
        surface.blit(panel, card.topleft)

        ui.draw_glow_text(surface, "SALAMAT SA PAGLARO! BACK ULIT! 😎",
                          (card.centerx, card.top + 78), size=42,
                          color=settings.GOLD, align="center", glow=10)
        ui.draw_text(surface, "PERYA KNIGHTS", (card.centerx, card.top + 122),
                     size=18, color=settings.TEXT_DIM, bold=True, align="center")
        ui.draw_divider(surface, (card.centerx, card.top + 144), width=200,
                        color=settings.NEON_PINK)

        ui.draw_text(surface, "Hanggang sa muli, kaibigan -", (card.centerx, card.top + 190),
                     size=20, color=settings.TEXT_BRIGHT, align="center")
        ui.draw_text(surface, "may bukas pa ang perya.", (card.centerx, card.top + 218),
                     size=20, color=settings.TEXT_BRIGHT, align="center")

        fade_alpha = ui.pulse(0.9, 0.35, 0.9)
        hint_color = ui.shade(settings.TEXT_DIM, fade_alpha)
        ui.draw_text(surface, "Nagsasara na...", (card.centerx, card.bottom - 30),
                     size=15, color=hint_color, align="center")
