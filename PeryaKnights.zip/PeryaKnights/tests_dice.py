"""
tests_dice.py
-------------
The dice are the heart of the game, so they get their own test. It rolls the
dice hundreds of times and checks the four things that must always be true.

    python tests_dice.py

  1. HONEST  - the number shown when a die stops is the number the game
               decided at the start. The face on screen can NEVER disagree
               with the result the credits are based on.
  2. ALWAYS SETTLES - every roll comes to rest in a sensible time. A die that
               spins forever would hang a round on the projector.
  3. STAYS IN THE MACHINE - no die ever escapes the walls, floor or ceiling,
               at any point during the tumble.
  4. FAIR    - over thousands of rolls each face 1-6 comes up about equally,
               so no number is secretly favoured.

It is headless and takes a few seconds. Every line prints PASS.
"""

import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import random
import pygame
from config import settings
from game.tumbler import Tumbler
from game.dice import Die, DiceSet
from game import cube

pygame.init()
pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))

fails = []


def check(name, condition):
    print(("PASS  " if condition else "FAIL  ") + name)
    if not condition:
        fails.append(name)


# a machine to roll inside, and the six dice
tumbler = Tumbler(pygame.Rect(60, 120, 860, 520))
dice = DiceSet(tumbler, size=26)
random.seed(1)


# ===========================================================================
# roll all six dice 200 times and watch everything
# ===========================================================================
print("=== rolling all six dice 200 times ===")

settle_frames = []
wrong_face = 0
escaped = 0
never_settled = 0
stuck_examples = 0

for _ in range(200):
    dice.roll()

    frames = 0
    while not dice.all_finished and frames < 60 * 15:   # 15s hard limit
        dice.update(1 / 60)
        frames += 1

        # while they move, no die may leave the machine
        for die in dice.dice:
            b = die.body
            if not (-tumbler.WALL_X - 0.02 <= b.x <= tumbler.WALL_X + 0.02):
                escaped += 1
            if not (tumbler.BACK_DEPTH - 0.02 <= b.depth
                    <= tumbler.FRONT_DEPTH + 0.02):
                escaped += 1
            if b.height < -0.5 or b.height > tumbler.ceiling_height() + 2:
                escaped += 1

    if not dice.all_finished:
        never_settled += 1
        continue

    settle_frames.append(frames)

    # every die must show the number it was told to finish on
    for die in dice.dice:
        if die.value != die.final_value:
            wrong_face += 1
        # and the maths must agree the shown face is really on top
        if cube.top_value(die.ax, die.ay, die.az) != die.final_value:
            wrong_face += 1

check("every die shows the number it settled on (honest)", wrong_face == 0)
check("no die ever left the machine (walls/floor/ceiling)", escaped == 0)
check("every roll settled within the time limit", never_settled == 0)

if settle_frames:
    settle_frames.sort()
    lo = settle_frames[0] / 60
    mid = settle_frames[len(settle_frames) // 2] / 60
    hi = settle_frames[-1] / 60
    print("      settle time: min %.2fs  median %.2fs  max %.2fs"
          % (lo, mid, hi))
    check("rolls finish in a sensible time (under 5s)", hi < 5.0)


# ===========================================================================
# the result is decided at THROW time, not at settle time
# ===========================================================================
print()
print("=== the result is fixed the moment the dice are thrown ===")
# force each die to a chosen result and confirm it lands on exactly that
forced_ok = True
for target in range(1, 7):
    die = Die("RED", tumbler, size=26)
    die.roll(final_value=target)
    frames = 0
    while not die.is_finished and frames < 60 * 15:
        die.update(1 / 60)
        frames += 1
    if die.value != target:
        forced_ok = False
check("a die told to land on N lands on exactly N", forced_ok)


# ===========================================================================
# fairness - each face 1..6 comes up about equally over many rolls
# ===========================================================================
print()
print("=== fairness: every face comes up about equally ===")
counts = {n: 0 for n in range(1, 7)}
one = Die("BLUE", tumbler, size=26)
TOTAL = 6000
for _ in range(TOTAL):
    one.roll()
    counts[one.final_value] += 1

percents = {n: counts[n] * 100 / TOTAL for n in counts}
print("      face spread: " + "  ".join("%d:%.1f%%" % (n, percents[n])
                                        for n in range(1, 7)))
# a fair die is 16.67% each; allow a small margin for randomness
fair = all(14.5 < percents[n] < 18.8 for n in counts)
check("no face is favoured (each near 16.7%%)", fair)
check("every face appears at least once", all(counts[n] > 0 for n in counts))


print()
if fails:
    print("DICE TEST: %d FAILURE(S) -> %s" % (len(fails), fails))
    sys.exit(1)
else:
    print("DICE TEST: THE DICE ARE HONEST, FAIR, AND NEVER BREAK")
