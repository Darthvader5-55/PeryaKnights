"""
tests_wiring.py
---------------
Checks the whole project is CONNECTED - every file imports, every screen the
menu points to really exists, and nothing refers to something that is gone.

    python tests_wiring.py

The other tests check that pieces WORK. This one checks the pieces are all
PRESENT and JOINED UP. It is the test that catches a missing file, a renamed
class, or a dead import before the game crashes on the projector.

It checks:
  1. every .py file in the project imports with no error
  2. every menu button leads to a screen the game can actually open
  3. every game mode reaches its result and back to the menu (full circle)
  4. the settings the code relies on all exist and are sane
  5. the assets folders the game expects are there

Every line prints PASS. It is headless and quick.
"""

import os
import sys
import importlib
import traceback

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import pygame
from config import settings

settings.SHOW_RULES_ON_ENTER = False

pygame.init()
surface = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))

fails = []


def check(name, condition):
    print(("PASS  " if condition else "FAIL  ") + name)
    if not condition:
        fails.append(name)


# ===========================================================================
# 1. every module in game/ and ui/ imports cleanly
# ===========================================================================
print("=== every code file imports (nothing missing or broken) ===")
bad_imports = []
for package in ("game", "ui", "config"):
    folder = os.path.join(HERE, package)
    for filename in sorted(os.listdir(folder)):
        if not filename.endswith(".py") or filename == "__init__.py":
            continue
        module = "%s.%s" % (package, filename[:-3])
        try:
            importlib.import_module(module)
        except Exception:
            bad_imports.append(module)
            print("    could not import %s:" % module)
            traceback.print_exc()
check("all game/ ui/ config/ modules import", not bad_imports)


# ===========================================================================
# 2. every menu button opens a real screen
# ===========================================================================
print()
print("=== every menu button leads to a real screen ===")
from game.game_manager import GameManager, GameState

manager = GameManager(surface)

# the main menu builds its buttons with on_click handlers - firing each one
# should land us on a genuinely different, working screen
manager.change_state(GameState.MAIN_MENU)
menu = manager.current_screen
for _ in range(3):
    manager.update(1 / 60)
    manager.draw(surface)

menu_buttons = getattr(menu, "buttons", [])
opened = 0
broke = False
for button in menu_buttons:
    if button.label in ("EXIT",):        # exit quits, do not fire it
        continue
    before = manager.state
    try:
        button.on_click()
        for _ in range(3):
            manager.update(1 / 60)
            manager.draw(surface)
    except Exception:
        broke = True
        traceback.print_exc()
        break
    if manager.state != before and manager.current_screen is not None:
        opened += 1
    manager.change_state(GameState.MAIN_MENU)
    menu = manager.current_screen

check("every menu button opened a screen without error",
      not broke and opened >= 7)      # 7 modes + settings, minus exit


# ===========================================================================
# 3. every mode goes full circle: open -> works -> ESC back to menu
# ===========================================================================
print()
print("=== every mode connects back to the menu ===")
MODES = [
    GameState.COLOR_ROYALE, GameState.OVER_UNDER, GameState.LUCKY_THREE,
    GameState.BEAT_HOUSE, GameState.CONSEQUENCE_POOL, GameState.BATTLE_ROYALE,
    GameState.ARCADE_DUEL, GameState.SETTINGS,
]
round_trip = True
for state in MODES:
    manager.change_state(state)
    for _ in range(4):
        manager.update(1 / 60)
        manager.draw(surface)
    manager.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE))
    for _ in range(3):
        manager.update(1 / 60)
        manager.draw(surface)
    if manager.state != GameState.MAIN_MENU:
        round_trip = False
        print("    %s did not return to the menu on ESC" % state)
check("every mode opens and returns to the menu", round_trip)


# ===========================================================================
# 4. the settings the code depends on all exist and make sense
# ===========================================================================
print()
print("=== the settings everything relies on are present and sane ===")
needed_numbers = ["SCREEN_WIDTH", "SCREEN_HEIGHT", "FPS", "STARTING_CREDITS",
                  "WIN_MULTIPLIER", "COUNTDOWN_SECONDS"]
missing = [n for n in needed_numbers if not hasattr(settings, n)]
check("all required settings exist", not missing)
check("screen size is sane", settings.SCREEN_WIDTH > 0 and settings.SCREEN_HEIGHT > 0)
check("there are six dice colours", len(settings.COLOR_ORDER) == 6)
check("every colour has an RGB value",
      all(c in settings.DICE_COLORS for c in settings.COLOR_ORDER))
check("bet amounts are a non-empty list",
      isinstance(settings.BET_AMOUNTS, (list, tuple)) and len(settings.BET_AMOUNTS) > 0)


# ===========================================================================
# 5. the required files are all PRESENT and not EMPTY
# ===========================================================================
# This is the check that catches a lost or blanked-out file - the exact thing
# that makes the UI vanish. A folder existing is not enough; the real files
# have to be there and have content in them.
print()
print("=== every required file is present and not empty ===")

REQUIRED = [
    "main.py",
    "config/settings.py",
    "config/consequences.json",
    "game/game_manager.py", "game/dice.py", "game/cube.py",
    "game/physics.py", "game/layers.py", "game/tumbler.py",
    "game/betting.py", "game/over_under.py", "game/lucky_three.py",
    "game/beat_house.py", "game/battle.py", "game/duel.py",
    "game/consequences.py", "game/audio.py",
    "ui/ui.py", "ui/scene.py", "ui/mode_screen.py", "ui/main_menu.py",
    "ui/color_royale_ui.py", "ui/over_under_ui.py", "ui/lucky_three_ui.py",
    "ui/beat_house_ui.py", "ui/consequence_ui.py", "ui/battle_royale_ui.py",
    "ui/duel_ui.py", "ui/settings_ui.py", "ui/result_ui.py",
    "ui/help_ui.py", "ui/particles.py",
]

missing = []
empty = []
for rel in REQUIRED:
    path = os.path.join(HERE, rel)
    if not os.path.isfile(path):
        missing.append(rel)
    elif os.path.getsize(path) < 20:      # a real code file is never this tiny
        empty.append(rel)

if missing:
    print("    MISSING: " + ", ".join(missing))
if empty:
    print("    EMPTY (0 bytes / blank): " + ", ".join(empty))

check("no required file is missing", not missing)
check("no required file is empty or blank", not empty)
check("all %d required files are present and have content" % len(REQUIRED),
      not missing and not empty)

# the UI folder specifically - the thing that "got lost" before
ui_files = [f for f in os.listdir(os.path.join(HERE, "ui")) if f.endswith(".py")]
check("the ui/ folder has all its screens (%d files)" % len(ui_files),
      len(ui_files) >= 15)


print()
if fails:
    print("WIRING TEST: %d FAILURE(S) -> %s" % (len(fails), fails))
    sys.exit(1)
else:
    print("WIRING TEST: EVERYTHING IS CONNECTED - NO MISSING PIECES")
