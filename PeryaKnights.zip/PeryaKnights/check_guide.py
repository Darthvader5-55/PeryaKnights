"""
check_guide.py
--------------
Checks that every line number in CODE_GUIDE.txt still points at the right
line.

    python check_guide.py

Line numbers go stale the moment you add a line above them, and a guide that
sends you to the wrong place is worse than no guide. Run this after you edit
anything and it will tell you which entries have drifted.

Entries written as prose rather than a quote are reported as "check by hand"
rather than as errors.
"""

import os
import re

GUIDE = "CODE_GUIDE.txt"
PATTERN = re.compile(r"^\s{4}([\w/\.]+\.py)\s*:\s*(\d+)\s+(.*)$")

os.chdir(os.path.dirname(os.path.abspath(__file__)))

if not os.path.exists(GUIDE):
    print("Could not find %s" % GUIDE)
    print()
    print("Looked in: %s" % os.getcwd())
    print()
    print("The file lives beside this script, in the same folder as main.py.")
    print("If it is not there, take a fresh copy from the zip.")
    print()
    print("Files in this folder:")
    for name in sorted(os.listdir(".")):
        if not name.startswith("."):
            print("    %s" % name)
    raise SystemExit(1)

checked = wrong = prose = 0

for line in open(GUIDE, encoding="utf-8").read().split("\n"):
    match = PATTERN.match(line)
    if not match:
        continue

    path, number, claim = match.group(1), int(match.group(2)), match.group(3).strip()
    checked += 1

    try:
        target = open(path, encoding="utf-8").read().split("\n")[number - 1]
    except (OSError, IndexError):
        print("MISSING   %s line %d does not exist" % (path, number))
        wrong += 1
        continue

    token = claim.split()[0].rstrip(",")
    if token in target:
        continue

    # the guide describes some lines instead of quoting them
    if token.islower() and not token.startswith(("def", "self", "_")):
        prose += 1
        continue

    print("DRIFTED   %s:%d" % (path, number))
    print("          guide says : %s" % claim[:64])
    print("          file has   : %s" % target.strip()[:64])
    wrong += 1

print()
print("%d line references checked" % checked)
print("%d described in words (check those by hand)" % prose)
if wrong:
    print("%d have DRIFTED - fix the numbers in %s" % (wrong, GUIDE))
else:
    print("0 drifted - every line number in the guide is correct")
