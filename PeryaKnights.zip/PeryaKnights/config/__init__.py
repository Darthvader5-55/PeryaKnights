"""Configuration package (settings + JSON data files)."""
