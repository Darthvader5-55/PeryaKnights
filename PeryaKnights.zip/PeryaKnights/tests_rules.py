"""
Rule tests: betting, consequences, duel.

Run it from inside the RiskAndRoll folder:

    python tests_rules.py

Every line should say PASS. Handy right before a demo.
"""
import os, sys
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
sys.path.insert(0, os.getcwd())
import pygame; pygame.init(); pygame.display.set_mode((100,100))
from config import settings
from game.betting import Betting
from game.consequences import ConsequenceBook, lowest_rollers, player_colors
from game.duel import Duel, PLAYER_A, PLAYER_B, TIE
fails=[]
def check(name, cond):
    if not cond: fails.append(name)
    print(("PASS  " if cond else "FAIL  ")+name)

# ---------------- betting ----------------
b = Betting(250)
check("empty selection rejected", b.validate()[0] is False)
b.select_color("BLUE"); b.select_number(4); b.select_amount(50)
check("full selection accepted", b.validate()[0] is True)
b.select_amount(500); check("bet above credits rejected", b.validate()[0] is False)
b.select_amount(50); b.place(); check("stake deducted on place", b.credits==200)
r = b.settle({"RED":1,"BLUE":4,"GREEN":1,"YELLOW":1,"PURPLE":1,"ORANGE":1})
check("win detected", r["won"])
check("win pays double (50 -> 100)", b.credits==300 and r["payout"]==100 and r["change"]==50)
b2 = Betting(100)
b2.select_color("RED"); b2.select_number(6); b2.select_amount(100); b2.place()
r2 = b2.settle({"RED":2,"BLUE":1,"GREEN":1,"YELLOW":1,"PURPLE":1,"ORANGE":1})
check("loss recorded", not r2["won"])
check("credits never go negative", b2.credits==0)
check("broke player cannot bet", b2.can_afford_anything() is False)
b3 = Betting(5); b3.select_color("RED"); b3.select_number(1); b3.select_amount(10)
check("insufficient credits rejected", b3.validate()[0] is False)
b3.reset_credits(); check("operator reset works", b3.credits==settings.STARTING_CREDITS)

# ---------------- consequences ----------------
book = ConsequenceBook()
check("consequences.json loaded cleanly", book.load_error is None)
check("has categories", len(book.category_names())>0)
for cat in book.category_names():
    cat2, text = book.random_consequence(cat)
    check("category %-9s returns text" % cat, cat2==cat and isinstance(text,str) and text)
c,t = book.random_consequence(); check("random category works", isinstance(t,str))
c,t = book.random_consequence("NOPE"); check("unknown category falls back safely", isinstance(t,str))
check("single loser", lowest_rollers({"RED":5,"BLUE":2,"GREEN":6})==["BLUE"])
check("tie returns all tied", lowest_rollers({"RED":2,"BLUE":2,"GREEN":5})==["RED","BLUE"])
check("all tied", len(lowest_rollers({"RED":3,"BLUE":3,"GREEN":3}))==3)
check("solo player loses", lowest_rollers({"RED":4})==["RED"])
check("sudden death subset", lowest_rollers({"RED":1,"BLUE":1,"GREEN":6}, ["RED","BLUE"])==["RED","BLUE"])
check("1 player colours", player_colors(1)==["RED"])
check("6 player colours", len(player_colors(6))==6)
check("count clamped high", len(player_colors(99))==6)
check("count clamped low", len(player_colors(0))>=1)

# ---------------- duel ----------------
d = Duel()
check("duel starts with nothing picked", d.team_a==[] and d.team_b==[])
check("player A picks first", d.next_picker()==PLAYER_A)
for c in ["RED","YELLOW","BLUE","PURPLE","GREEN","ORANGE"]:
    d.tap(c)
check("draft alternated A,B,A,B...", d.team_a==["RED","BLUE","GREEN"]
      and d.team_b==["YELLOW","PURPLE","ORANGE"])
check("teams ready", d.teams_ready)
check("full teams refuse another pick", d.take("RED") is False)
d.tap("RED")
check("tapping your own colour releases it", d.team_a==["BLUE","GREEN"])
check("released colour is free again", "RED" in d.unpicked())
check("the short team picks next", d.next_picker()==PLAYER_A)
d.tap("RED")
res = d.judge({"RED":4,"BLUE":6,"GREEN":3,"YELLOW":2,"PURPLE":5,"ORANGE":4})
check("A total 13", res["total_a"]==13)
check("B total 11", res["total_b"]==11)
check("A wins", res["winner"]==PLAYER_A)
check("score tracked", d.wins[PLAYER_A]==1)
tie = d.judge({"RED":1,"BLUE":1,"GREEN":1,"YELLOW":1,"PURPLE":1,"ORANGE":1})
check("equal totals -> tie", tie["winner"]==TIE)
check("rematch counted", d.rematches==1)
check("tie adds no win", d.wins[PLAYER_A]==1 and d.wins[PLAYER_B]==0)

# fewer dice each
d2 = Duel()
d2.set_dice_count(1)
check("dice count set to 1", d2.dice_count==1)
d2.tap("RED"); d2.tap("BLUE")
check("1 v 1 is ready after two picks", d2.teams_ready)
check("only two colours are in play", d2.in_play()==["RED","BLUE"])
r1 = d2.judge({"RED":6,"BLUE":2,"GREEN":6,"YELLOW":6,"PURPLE":6,"ORANGE":6})
check("unchosen dice are ignored in the score", r1["total_a"]==6 and r1["total_b"]==2)
d2.set_dice_count(3)
check("changing the dice count clears the picks", d2.team_a==[] and d2.team_b==[])
d2.set_dice_count(9)
check("dice count cannot exceed three", d2.dice_count==3)
d2.auto_fill()
check("auto fill deals 3 and 3", len(d2.team_a)==3 and len(d2.team_b)==3)
check("auto fill never repeats a colour", not set(d2.team_a) & set(d2.team_b))
print("\nRESULT:", "ALL PASS" if not fails else "FAILURES -> %s"%fails)
