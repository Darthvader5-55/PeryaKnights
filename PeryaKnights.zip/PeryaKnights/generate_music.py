"""
generate_music.py
------------------
One-off script: writes assets/sounds/music.wav, a short looping instrumental
built the same way every other sound in the game is - plain Python maths,
no external samples, no internet.

WHY A GENERATED FILE INSTEAD OF THE USUAL "drop a file in" APPROACH
game/audio.py already looks for assets/sounds/music.wav and loops it
automatically with no code change - this script just gives it something to
find. It leans on a five-note (pentatonic) scale and a plucked-string style
envelope, which is the same shape a rondalla (the guitar-and-bandurria string
band you hear at a real Philippine fiesta) plays: a bright pluck that decays
fast, with a soft bass note underneath holding the beat.

Run it once from the project folder:
    python generate_music.py
It only needs to be run again if you want to change the melody below - the
game itself never calls this file.
"""

import math
import struct
import wave

RATE = 22050
TEMPO_BPM = 118
BEAT = 60.0 / TEMPO_BPM        # seconds per quarter note
EIGHTH = BEAT / 2.0

# A, B pentatonic-major frequencies (Hz) - C major pentatonic, two octaves,
# picked because it has no "sad" or "tense" notes in it: everything in this
# scale sounds cheerful together, which is what a perya at night should feel
# like.
C4, D4, E4, G4, A4 = 261.63, 293.66, 329.63, 392.00, 440.00
C5, D5, E5, G5 = 523.25, 587.33, 659.25, 783.99
REST = 0.0

# One 8-bar melody, in eighth notes. It is written to START and END on the
# root note (C) at a bar boundary, so the loop join has no audible seam.
MELODY = [
    E4, G4, A4, G4,  E4, D4, C4, REST,
    E4, G4, A4, C5,  A4, G4, E4, REST,
    G4, A4, C5, D5,  C5, A4, G4, REST,
    A4, G4, E4, D4,  E4, D4, C4, REST,
    E4, G4, A4, G4,  E4, D4, C4, REST,
    E4, G4, A4, C5,  D5, C5, A4, G4,
    A4, G4, E4, G4,  A4, E4, D4, REST,
    C4, REST, REST, REST, REST, REST, REST, REST,
]

# a soft bass pulse under every bar (four eighth notes = one bar here)
BASS = [C4 / 2, REST, G4 / 2, REST]


def envelope(i, n, attack_frac=0.02, curve=3.2):
    attack = max(1, int(n * attack_frac))
    if i < attack:
        return i / attack
    return max(0.0, (1.0 - (i - attack) / max(1, n - attack)) ** curve)


def pluck(freq, seconds, volume):
    """A single plucked note: a bright fundamental plus a quiet octave and
    fifth overtone, gone almost as fast as it arrives - a bandurria pluck,
    not an organ hold."""
    n = int(RATE * seconds)
    if freq <= 0:
        return [0.0] * n
    out = []
    for i in range(n):
        t = i / RATE
        wave_val = (math.sin(2 * math.pi * freq * t) * 1.0 +
                    math.sin(2 * math.pi * freq * 2 * t) * 0.22 +
                    math.sin(2 * math.pi * freq * 1.5 * t) * 0.14)
        out.append(wave_val * envelope(i, n, attack_frac=0.01, curve=2.6) * volume)
    return out


def mix_into(buffer, notes, note_len, volume, start=0.0):
    offset = int(start * RATE)
    for note in notes:
        samples = pluck(note, note_len, volume)
        for i, value in enumerate(samples):
            pos = offset + i
            if pos < len(buffer):
                buffer[pos] += value
        offset += len(samples)


def build():
    total_seconds = len(MELODY) * EIGHTH
    total_samples = int(RATE * total_seconds)
    buffer = [0.0] * total_samples

    mix_into(buffer, MELODY, EIGHTH, volume=0.30)

    bar_len = EIGHTH * 8
    bass_notes = (BASS * (len(MELODY) // len(BASS) + 1))[:len(MELODY) // 2]
    mix_into(buffer, bass_notes, EIGHTH * 2, volume=0.16)

    # gentle limiter, so the loudest overlaps never clip
    peak = max(1.0, max(abs(v) for v in buffer))
    data = bytearray()
    for value in buffer:
        sample = int((value / peak) * 0.85 * 32767)
        sample = max(-32767, min(32767, sample))
        data += struct.pack("<h", sample)
    return bytes(data)


def main():
    import os
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "assets", "sounds", "music.wav")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    audio = build()
    with wave.open(out_path, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(RATE)
        wav_file.writeframes(audio)
    print("wrote", out_path, "(%.1fs)" % (len(audio) / 2 / RATE))


if __name__ == "__main__":
    main()
