RISK & ROLL - a 2.5D Pygame arcade dice game
===========================================
A BSIT first-year project. Python + Pygame only. No 3D engine.

REQUIREMENTS
------------
  Python 3.11 or newer (3.13 works)
  pygame ->  pip install pygame

RUNNING ON A PHONE (Pydroid)
----------------------------
The game was built for a laptop and runs fastest there. On a phone through
Pydroid it will be slower and the window is squeezed to fit the screen -
that is Pydroid shrinking the whole 1280x720 picture, not a bug.

THE EASY WAY: open config/settings.py and set

    PHONE = True

That one switch turns on everything a phone needs at once - it fits the
screen, drops the heavy effects, lowers the resolution and aims for 30 fps.

HOW IT FILLS THE SCREEN - config/settings.py, FIT_MODE:
  "letterbox"  (default) keeps the game's shape with black bars. Best held
               SIDEWAYS, where the game fills the screen and looks right.
  "stretch"    fills the WHOLE screen edge to edge with no bars. Use this if
               you must play UPRIGHT - the picture is stretched a bit tall
               (dice and text look longer) but nothing is cut off and every
               button still works where you tap it.

So: sideways -> leave FIT_MODE "letterbox". Upright -> set it "stretch".

STILL LAGGY? config/settings.py, PHONE_SPEED:
  "normal"  (default) 640x360 - fine for most phones
  "fast"    480x270 - draws less, looks a bit blocky, but smoother on a
            phone that still struggles. It is stretched up to fill the
            screen either way, so "fast" just means the phone hardware does
            more of the stretching, which it handles cheaply.

Note: a phone running Python will never match a laptop. These settings make
it as smooth as the software can - if it is still slow after PHONE_SPEED
"fast", the phone itself is the limit.

Leave PHONE = False on a laptop.

Behind that one switch, it does BOTH of these:

  A. HOLD THE PHONE SIDEWAYS (landscape). The game is a wide shape, like a
     video - upright it shrinks into a thin strip, sideways it fills the
     screen. This is the single biggest difference.

  B. Turn ON phone-fit so the whole game fits with nothing cut off the edges.
     Open config/settings.py and set:
         PHONE_FIT = True
     The game is drawn on its own canvas and shrunk to fit your screen, and
     taps are mapped to the right spot automatically. There may be black bars
     around it - that is the game keeping its shape so nothing is lost.

Then also turn ON low-power mode for speed. Two ways:

  1. Open config/settings.py and change one line:
         LOW_POWER = True
     This also drops the resolution to 800x450 and the frame rate to 30,
     which is the biggest speed-up. Do this BEFORE starting the game.

  2. Or, while the game is running, open SETTINGS and tap LOW POWER (PHONE).
     That switches off the heavy effects live. The lower resolution only
     applies when set in the file, because the window is already open.

Low-power turns off three things that cost the most and matter the least:
the floor reflection, the dice drifting in the room, and the screen
scanlines. The game plays exactly the same - it just looks a little plainer.
Measured about twice as fast to draw.

On a laptop, leave LOW_POWER = False for the full visuals.

FULLSCREEN
----------
The game starts filling the whole screen. Press F11 (or Alt+Enter) to drop
back to a window, and again to go back. There is also a FULLSCREEN row in
SETTINGS.

It is drawn at 1280x720 and then stretched to fit your screen, so every
button stays exactly where it was designed to be - just bigger. The picture
keeps its shape, so a widescreen laptop gets thin black bars at the sides
instead of a stretched, squashed image.

To start in a window instead, set FULLSCREEN = False in config/settings.py.

HOW TO RUN
----------
  1. Open a terminal inside this folder (the one holding main.py).
  2. python main.py          (or: py main.py)

CONTROLS
--------
  F11      fullscreen on / off  (Alt+Enter works too)
  Mouse    everything
  H or ?   HOW TO PLAY - every mode explains itself on screen. The card
           also opens BY ITSELF whenever a mode starts, because at a booth a
           new person walks up every round. Turn that off with
           SHOW_RULES_ON_ENTER in config/settings.py.
  ESC      back to the menu / quit from the menu
  SPACE    roll / play again

  Color Royale keyboard shortcuts (a booth operator with a queue is much
  faster on the keyboard than with a mouse):
    Q W E A S D   pick red, blue, green, yellow, purple, orange
    1 - 6         pick the number
    L             lucky pick - fills in a random colour, number and bet
    SPACE         place the bet / play again
    R             new player: credits back to the start

  Consequence Pool: click any player's name to type a real name over it.
                    Enter saves, Escape cancels.
                    Tap the five DIFFICULTY buttons to switch levels on/off.
  Arcade Duel:      first choose how many dice each player rolls (1, 2 or 3),
                    then take turns tapping colours. Player A picks, then B,
                    then A, and so on. Tap a colour you own to put it back.
                    RANDOM deals for you. Keys 1 / 2 / 3 set the dice count.

CHECK IT STILL WORKS
--------------------
  python tests_rules.py         core rules, no window   -> ALL PASS
  python tests_modes_rules.py   newer modes, no window  -> ALL PASS
  python tests_playthrough.py   plays real rounds       -> ALL CHECKS PASSED
  python tests_new_features.py  names, levels, picking  -> CHECKS PASSED
  python tests_modes.py         plays the newer modes   -> ALL CHECKS PASSED
  python tests_help.py          the HOW TO PLAY card    -> ALL CHECKS PASSED
  python tests_typing.py        typing names vs shortcuts -> ALL CHECKS PASSED
  python update_guide.py        rebuild the guide's index from the code
  python check_guide.py         CODE_GUIDE line numbers -> 0 drifted
Run both before you present. They take about a minute.

See CODE_GUIDE.txt to understand the code and find what to change.
See PRESENTATION_NOTES.txt for the demo order and the questions you will be asked.

WHAT IS WHERE
-------------
  main.py                  starts Pygame, runs the game loop
  config/settings.py       every number and colour in the game
  config/consequences.json the dares, in five difficulty levels, editable in Notepad
  game/game_manager.py     which screen is active, and switching between them
  game/cube.py             THE 3D DICE: rotates a real cube's 8 corners in 3D,
                           flattens them onto the screen and draws only the
                           faces pointing at you. No engine, no libraries.
  game/layers.py           THE 2.5D CORE: perspective maths + draw order + shadows
  game/dice.py             die artwork, the Die class, and DiceSet (all six)
  game/physics.py          gravity, bouncing, walls, friction
  game/tumbler.py          the machine: back wall, interior, glass, frame
  game/betting.py          credits and the Color Royale rules (no drawing code)
  game/consequences.py     loads the JSON, finds the lowest roll, sudden death
  game/duel.py             two teams of three dice, totals, winner, colour trading
  game/over_under.py       bet on the TOTAL of six dice; real counted odds
  game/lucky_three.py      pick three colours and a number; paid per hit
  game/battle.py           last player standing, reuses the sudden-death code
  game/beat_house.py       three dice against the machine; an exactly fair mode
  game/history.py          the last-rounds strip and the win/loss streaks
  game/audio.py            sounds; makes its own beeps if no files are present
  ui/ui.py                 fonts, panels, buttons, glass, gradients
  ui/scene.py              the arcade room: ceiling, far cabinets, floor haze,
                           and the mirrored reflection under the machine
  ui/mode_screen.py        the shared skeleton for the three game modes
  ui/main_menu.py          menu
  ui/color_royale_ui.py    betting mode
  ui/consequence_ui.py     consequence mode
  ui/duel_ui.py            1 vs 1 mode
  ui/over_under_ui.py      OVER / UNDER screen
  ui/lucky_three_ui.py     LUCKY THREE screen
  ui/battle_royale_ui.py   BATTLE ROYALE screen
  ui/beat_house_ui.py      BEAT THE HOUSE screen
  ui/result_ui.py          the pop-up result card, shared by every mode
  ui/help_ui.py            the HOW TO PLAY card, shared by every mode
  ui/particles.py          the confetti burst on a win
  ui/settings_ui.py        sound, volume, FPS counter, reset credits
  assets/                  empty on purpose - all art is drawn in code.
                           Drop click.wav, win.wav, lose.wav, bounce.wav,
                           place.wav or beep.wav into assets/sounds/ and they
                           are used automatically.

THINGS YOU MIGHT WANT TO CHANGE (all in config/settings.py)
-----------------------------------------------------------
  STARTING_CREDITS   how much a player starts with
  BET_AMOUNTS        the four bet buttons
  WIN_MULTIPLIER     the payout. READ THE COMMENT ABOVE IT before the booth runs.
  COUNTDOWN_SECONDS  the 3-2-1 before a roll
  SCREEN_WIDTH/HEIGHT, FPS, volumes
  SHOW_RULES_ON_ENTER  whether the rules card opens on its own
  LOW_POWER            phone / slow-machine mode: smaller, faster, plainer
  FULLSCREEN           start filling the screen (True) or in a window

BUILD STATUS
------------
  PHASE 1  window, game loop, main menu
  PHASE 2  2.5D stage, depth layers, lighting, shared panels
  PHASE 3  the tumbler
  PHASE 4  one die: gravity, bounce, spin, squash, result
  PHASE 5  six dice, staggered launches, dice-on-dice knocks
  PHASE 6  dice results
  PHASE 7  Color Royale interface
  PHASE 8  credits and betting
  PHASE 9  the full Color Royale round
  PHASE 10 Consequence Pool with sudden death
  PHASE 11 Arcade Duel
  PHASE 12 result screens
  PHASE 13 audio
  PHASE 14 polish
  ALL DONE.

ADDED AFTER PHASE 14
--------------------
  Arcade Duel       a real setup phase: choose 1, 2 or 3 dice each, then the
                    two players take turns picking their own colours. Only the
                    chosen dice appear in the machine and count in the score.
  Consequence Pool  type real player names; five difficulty levels
                    (WARM UP, EASY, FUNNY, HARD, EXTREME) that the operator
                    can switch on and off from the screen
  Color Royale      last-rounds strip, win/loss streaks, LUCKY PICK,
                    confetti on a win, full keyboard shortcuts

VISUAL REBUILD (after the modes were finished)
----------------------------------------------
  Dice        no longer a picture being spun. game/cube.py turns a real cube
              in 3D every frame, so faces rotate away and new ones come into
              view. A roll now shows about 7 different faces on the way down,
              then topples into the stored result.
  Room        floor reflection of the machine, a ceiling with light bars
              running to the vanishing point, dim arcade cabinets along the
              back wall, and light haze on the horizon. The machine was also
              made smaller so the room is visible around it.
  Buttons     a visible side that the face drops into when pressed, dice pips
              instead of digits on the NUMBER buttons, and a credit counter
              that ticks up after a win instead of snapping.

SECOND VISUAL PASS
------------------
  Pips        no longer flat circles pasted on a slanted face. A pip is now a
              ring of points bent through the same face corners as everything
              else, so it squashes into an ellipse when the face turns away,
              exactly like a dot printed on real plastic. Faces also got a
              bevel and pips a shaded rim, so the cube reads as moulded
              plastic instead of cut card.
  Machine     the empty back panel now has a bouncing equaliser and a chase of
              marquee lamps running round its border.
  Room        PA speaker stacks stand either side of the machine, cones
              pumping on a slow beat, with shadows pooled under them.
              Later additions: lit wall signs above the speakers with pips
              chasing down them, a painted ring on the floor for the machine
              to stand in, a dice-pip pattern in the empty ends of the title
              bar, and bolts in the corners of the betting panel.
  Depth     the machine stands on a base that flares out towards the viewer,
              the control panel has a slanted edge so it reads as a slab with
              thickness, and a few small 3D dice tumble slowly in the room
              behind the machine.
  Rules     every mode has a "?" in the corner (or press H) that opens a card
              with a one-line summary, the steps in order, the payouts and the
              keyboard shortcuts, and it opens by itself when the mode starts.
              At a booth nobody reads a printed sign - the screen has to
              explain itself.
  Music     drop a file named music.ogg (or .mp3 / .wav) into assets/sounds/
              and it loops as background music - no code change. See
              assets/sounds/HOW_TO_ADD_MUSIC.txt. Volume: MUSIC_VOLUME in
              config/settings.py.
  Sound     the tumbler rumbles for as long as the dice are moving, and the
              rumble fades with them rather than cutting off. Individual
              bounces, wall hits and dice knocking each other each make their
              own clack on top of it, so what you hear matches what you see.

FOUR MORE MODES
---------------
  Seven modes no longer fit one menu column, so the menu is now two:
  BETTING GAMES on the left, PARTY GAMES on the right.

  OVER / UNDER      credits. Bet whether the total of all six dice lands
                    under 21, over 21, or exactly on it. Pays 2x, 2x and 9x
                    against real chances of 45.4%, 45.4% and 9.3%. Much
                    kinder odds than Color Royale, so a queue keeps winning.
                    Keys: U, O, E to choose.
  LUCKY THREE       credits. Pick THREE colours, pick a NUMBER, pick a bet.
                    All six dice roll but only your three count, and every one
                    of them showing your number is a hit:
                        1 hit pays 2x    2 hits pay 3x    3 hits pay 10x
                    You win something 42% of rounds - nearly a coin flip, and
                    far kinder than Color Royale's 1 in 6. The hit counter
                    climbs live while the dice settle.
                    Keys: 1-6 pick the number, L for random colours.

                    (This replaced HIGHER OR LOWER, which could be beaten:
                    with a 1 showing, HIGHER could not lose, and you could
                    cash out of any risky round for free. Rather than keep
                    patching it, the mode was rebuilt around real choices.)
  BATTLE ROYALE     free play, 2-6 players. Lowest roll is knocked out each
                    round until one is left. Ties go to sudden death. Click
                    any player's name to type a real one over the colour, so
                    the screen says MIKE IS OUT instead of BLUE IS OUT.
  BEAT THE HOUSE    credits. Choose how many dice each side rolls (1, 2 or 3)
                    and which colours are yours; the machine takes the rest.
                    Your dice against the machine's.
                    A draw returns your stake, which makes this mode exactly
                    fair - the booth neither gains nor loses on it. It exists
                    because Arcade Duel needs two people and most of a booth
                    queue is one person on their own.

STORY + MUSIC
-------------
  Intro screen   The game now opens on a short Tagalog story card ("Bawat
                 taon, dumarating ang perya sa barangay...") before the main
                 menu, framing the whole game as one night at the perya.
                 Any key or click moves on. See ui/intro_ui.py.
  Music          assets/sounds/music.wav is a short looping instrumental,
                 generated (not recorded) by generate_music.py using the same
                 in-code sound approach as every other sound in the game - a
                 five-note pentatonic melody with a plucked-string envelope,
                 meant to suggest a rondalla at a fiesta. Run
                 "python generate_music.py" again if you want to change the
                 melody (it is defined as a plain list of notes near the top
                 of the file). Delete the .wav file to go back to no music.
  Win / lose     game/audio.py's generated win/lose stingers were reworked to
                 be a brighter ascending flourish on a win and a soft
                 deflating dip on a loss, instead of generic arcade beeps.

BRAND FONT + SMALL FIXES
-------------------------
  Font           config/settings.py FONT_FILE now points to
                 assets/fonts/Poppins-Bold.ttf (bundled, SIL Open Font
                 License - free to include and submit). Every label, button
                 and header in the game now uses the same bold rounded
                 typeface as the logo and poster, instead of falling back to
                 whatever font happened to be on the machine. Delete the file
                 and set FONT_FILE back to None to go back to the old look.
  Confetti       Arcade Duel (Sabong ng Dais) was the one mode missing the
                 paper-confetti win burst every other mode already had -
                 added, so every win screen in the game now celebrates the
                 same way.
  Music volume   SETTINGS > VOLUME UP/DOWN now also raises/lowers the music
                 track, not just sound effects - it only touched sfx_volume
                 before there was a music track to control.

DICE, SOUND VARIETY, AND A GOODBYE
-----------------------------------
  Sun-pip dice    Every pip on every die is now an eight-rayed sun (the same
                  sun as the Philippine flag) instead of a plain dot -
                  game/cube.py, _PIP_RING. One shape, reused everywhere pips
                  are drawn, so every die in the game changed at once.
  Mode win/lose   Lucky Three (Panagbenga), Beat the House (MassKara) and
                  Battle Royale (Ati-Atihan) now each have their own win and
                  lose stinger instead of sharing the default one - a bright
                  bell run, a bigger brassy hit, and a drum-plus-horn cue.
                  See the win_lucky / win_beat_house / win_battle entries in
                  game/audio.py. The other four modes still use the default
                  win/lose from before.
  Goodbye screen  EXIT and ESC on the main menu no longer close the window
                  straight away - they go to a short "SALAMAT SA
                  PAGLALARO!" card first (ui/exit_ui.py), which closes itself
                  after ~2.5s or on any key/click. Clicking the window's own
                  X button still closes immediately, as normal.

TITLE READABILITY FIX
----------------------
  The ceiling bunting was tiled too tightly (7 dense rows of triangles) and
  competed with the "PERYA KNIGHTS" title sitting right in front of it -
  see ui/scene.py _draw_ceiling. Cut down to 4 loosely-spaced rows at lower
  opacity, so it reads as a garland instead of wallpaper. The title text
  also had a heavy glow (blurring the letters) and nothing separating it
  from the background - ui/main_menu.py _draw_title now draws a soft dark
  band behind the wordmark first, and the glow is turned down, so the title
  stays crisp no matter what's happening behind it.

QUIETER TEXT EVERYWHERE
------------------------
  ui.draw_glow_text() / make_glow_text() are used for almost every title and
  header in the game (mode headers, "GUMUGULONG...", result screens, the
  main menu, the intro/exit cards) - one function behind most of the text on
  screen. Its default glow dropped from 8 to 4 and the halo itself is
  fainter (alpha 38 -> 26), so all of that text got calmer in one change
  instead of needing to be fixed screen by screen. If any one title still
  feels too soft or too glowy after trying it, that screen's own
  draw_glow_text(...) call can pass a specific glow=N to override just that
  one.

PARUSAHAN (CONSEQUENCE POOL) - FULL FILIPINO PASS
---------------------------------------------------
  This mode's own header, messages and dares were still in English even
  though the rest of the game had already gone Tagalog. Brought it in line:
    Title / header    "CONSEQUENCE POOL" -> "PARUSAHAN", with a new subtitle
                       ("MAS MABABA, MAS MALAS KA"). config/settings.py's
                       MODE_FESTIVALS key was updated to match, so this mode
                       keeps its own Pahiyas (harvest festival) green-and-
                       gold background accent instead of falling back to the
                       default colours.
    Difficulty levels config/consequences.json's five levels are now Tagalog
                       (SIMULA, MADALI, KOMEDYA, MAHIRAP, EKSTREMA) instead of
                       WARM UP / EASY / FUNNY / HARD / EXTREME, and every
                       dare inside them was rewritten in Tagalog with local
                       flavour - tinikling steps, Bahay Kubo, teleserye
                       villains, "Mabuhay!", and so on. The in-code fallback
                       list in game/consequences.py (used only if the JSON
                       fails to load) was updated to match.
    On-screen text     Every message this mode shows - player count, name
                       entry, the tie/reroll prompt, result labels, the HOW
                       TO PLAY card - is now Tagalog. "SUDDEN DEATH" became
                       "MULING IGULONG" (roll again), which also reads
                       better for a school event than the original English.
  Edit config/consequences.json in Notepad to add, remove or reword dares -
  same as before, no code changes needed.
