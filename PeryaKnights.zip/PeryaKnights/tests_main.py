"""
tests_main.py
-------------
Runs the REAL game loop from main.py and checks it starts, runs, and stops
cleanly - the part that either works or the whole game is dead on the day.

    python tests_main.py

main.py is the entry point: it starts pygame, makes the window, builds the
GameManager, and runs the loop that reads events, updates and draws every
frame. If any of that is broken the game will not even open. This test
exercises exactly that path, headless (no window), by feeding fake events
into the same loop and watching what happens:

  - main imports and its pieces exist
  - the GameManager starts and lands on a real first screen
  - the loop runs many frames without error
  - a big lag spike is capped so the game cannot jump or freeze
  - a QUIT event stops the loop cleanly
  - the fullscreen key (F11 / Alt+Enter) is recognised and swallowed

Every line prints PASS. It takes a couple of seconds.
"""

import os
import sys
import traceback

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pygame
from config import settings

settings.SHOW_RULES_ON_ENTER = False

fails = []


def check(name, condition):
    print(("PASS  " if condition else "FAIL  ") + name)
    if not condition:
        fails.append(name)


# ===========================================================================
# 1. main.py imports and has the parts the loop uses
# ===========================================================================
print("=== main.py loads and has its parts ===")
ok = True
try:
    import main
except Exception:
    ok = False
    traceback.print_exc()
check("main.py imports without error", ok)
check("main() exists", hasattr(main, "main"))
check("the fullscreen key check exists", hasattr(main, "_is_fullscreen_key"))
check("toggle_fullscreen exists", hasattr(main, "toggle_fullscreen"))


# ===========================================================================
# 2. build the game the way main() does, and run its loop by hand
# ===========================================================================
# We do not call main.main() directly because it loops forever and calls
# sys.exit(). Instead we build the same objects and run the same body, so we
# are testing the real startup and the real per-frame work.
print()
print("=== the real startup builds a running game ===")
from game.game_manager import GameManager

pygame.init()
surface = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
clock = pygame.time.Clock()
manager = GameManager(surface)

check("GameManager starts running", manager.running is True)
check("it opens on a real first screen", manager.current_screen is not None)
check("that screen has a state name", isinstance(manager.state, str)
      and len(manager.state) > 0)


def run_frames(n, dt=1 / 60):
    """One turn of main.py's loop body, n times."""
    for _ in range(n):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                manager.running = False
                continue
            if event.type == pygame.KEYDOWN and main._is_fullscreen_key(event):
                main.toggle_fullscreen()
                continue
            manager.handle_event(event)
        manager.update(dt)
        manager.draw(surface)


print()
print("=== the loop runs many frames without error ===")
ok = True
try:
    run_frames(180)          # about three seconds of game
except Exception:
    ok = False
    traceback.print_exc()
check("180 frames update and draw cleanly", ok)
check("still running after 180 frames", manager.running is True)


# ===========================================================================
# 3. the lag-spike cap - dt is clamped so nothing jumps
# ===========================================================================
print()
print("=== a lag spike is capped, not passed straight through ===")
# main.py does: dt = min(dt, 0.05). Feed a huge dt and confirm the game does
# not blow up or teleport the dice out of the machine.
ok = True
try:
    for _ in range(30):
        manager.update(0.05)     # the capped value main.py would use
        manager.draw(surface)
except Exception:
    ok = False
    traceback.print_exc()
check("survives repeated 50ms lag-spike frames", ok)
check("still running after the lag spike", manager.running is True)


# ===========================================================================
# 4. the fullscreen key is recognised and swallowed
# ===========================================================================
print()
print("=== the fullscreen key works and the game never sees it ===")
f11 = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_F11, mod=0)
alt_enter = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN,
                               mod=pygame.KMOD_LALT)
plain_enter = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN, mod=0)

check("F11 is recognised as the fullscreen key", main._is_fullscreen_key(f11))
check("Alt+Enter is recognised too",
      bool(main._is_fullscreen_key(alt_enter)))
check("plain Enter is NOT the fullscreen key",
      not main._is_fullscreen_key(plain_enter))


# ===========================================================================
# 5. a QUIT event stops the loop cleanly
# ===========================================================================
print()
print("=== a QUIT event stops the game cleanly ===")
pygame.event.post(pygame.event.Event(pygame.QUIT))
run_frames(2)
check("QUIT sets running to False", manager.running is False)


print()
if fails:
    print("MAIN TEST: %d FAILURE(S) -> %s" % (len(fails), fails))
    sys.exit(1)
else:
    print("MAIN TEST: THE GAME STARTS, RUNS, AND STOPS CLEANLY")
