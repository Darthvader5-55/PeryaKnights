"""
Rule tests for the four newer modes. No window, no clicking - just the maths.

    python tests_modes_rules.py

Includes the odds checks: the stated chances for Over/Under are compared
against a 60,000-roll simulation, and Beat the House is checked to be fair.
"""
import os, sys, random
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
sys.path.insert(0, os.getcwd())
import pygame; pygame.init(); pygame.display.set_mode((80,80))
from config import settings
from game.over_under import OverUnderGame, UNDER, OVER, EXACT, result_for, PAYOUT, CHANCE
from game.battle import BattleRoyale
from game.beat_house import BeatTheHouse, PLAYER_COLORS, HOUSE_COLORS
from game.duel import PLAYER_A, PLAYER_B, TIE
fails=[]
def check(name, cond):
    if not cond: fails.append(name)
    print(("PASS  " if cond else "FAIL  ")+name)

print("--- OVER / UNDER ---")
check("20 is under", result_for(20)==UNDER)
check("21 is exact", result_for(21)==EXACT)
check("22 is over", result_for(22)==OVER)
check("6 is under, 36 is over", result_for(6)==UNDER and result_for(36)==OVER)
g = OverUnderGame(250)
check("nothing chosen is invalid", g.validate()[0] is False)
g.select_choice(OVER); g.select_amount(50)
check("complete bet is valid", g.validate()[0] is True)
g.select_amount(9999); check("over-credits refused", g.validate()[0] is False)
g.select_amount(50); g.place(); check("stake taken", g.credits==200)
r = g.settle({"RED":6,"BLUE":6,"GREEN":6,"YELLOW":6,"PURPLE":6,"ORANGE":1})
check("total added correctly", r["total"]==31)
check("over wins", r["won"] and r["payout"]==100 and g.credits==300)
g2 = OverUnderGame(100); g2.select_choice(EXACT); g2.select_amount(10); g2.place()
r2 = g2.settle({"RED":4,"BLUE":4,"GREEN":4,"YELLOW":3,"PURPLE":3,"ORANGE":3})
check("exact 21 detected", r2["total"]==21 and r2["won"])
check("exact pays 9x", r2["payout"]==90)
g3 = OverUnderGame(20); g3.select_choice(UNDER); g3.select_amount(20); g3.place()
r3 = g3.settle({c:6 for c in ["RED","BLUE","GREEN","YELLOW","PURPLE","ORANGE"]})
check("loss leaves zero, never negative", g3.credits==0 and not r3["won"])
# simulate the advertised odds
random.seed(3); hits={UNDER:0, EXACT:0, OVER:0}
for _ in range(60000):
    hits[result_for(sum(random.randint(1,6) for _ in range(6)))]+=1
print("  simulated: under %.4f exact %.4f over %.4f" %
      (hits[UNDER]/60000, hits[EXACT]/60000, hits[OVER]/60000))
check("stated chances match a 60k simulation",
      all(abs(hits[k]/60000 - CHANCE[k]) < 0.01 for k in hits))

print("\n--- LUCKY THREE ---")
from game.lucky_three import LuckyThreeGame, PAYOUT, CHANCE, payout_for
lt = LuckyThreeGame(250, all_colors=settings.COLOR_ORDER)
check("starts with no colours", lt.colors == [])
check("nothing chosen is invalid", lt.validate()[0] is False)
lt.tap_color("RED"); lt.tap_color("BLUE"); lt.tap_color("GREEN")
check("three colours taken", lt.has_colors)
check("a fourth colour is refused", lt.tap_color("YELLOW") is False
      and len(lt.colors) == 3)
check("tapping your own colour gives it back",
      lt.tap_color("RED") is False and lt.colors == ["BLUE", "GREEN"])
lt.tap_color("RED")
lt.select_number(4); lt.select_amount(50)
check("complete bet is valid", lt.validate()[0] is True)
lt.select_amount(9999); check("over-credits refused", lt.validate()[0] is False)
lt.select_amount(50); lt.place(); check("stake taken", lt.credits == 200)
r = lt.settle({"RED":4,"BLUE":4,"GREEN":1,"YELLOW":4,"PURPLE":4,"ORANGE":4})
check("only the player's own dice count", r["hits"] == 2)
check("two hits pay 3x", r["payout"] == 150 and lt.credits == 350)
lt.select_number(6); lt.select_amount(10); lt.place()
r = lt.settle({c: 6 for c in settings.COLOR_ORDER})
check("all three hitting is a jackpot", r["hits"] == 3 and r["jackpot"])
check("jackpot pays 10x", r["payout"] == 100)
lt.select_number(1); lt.select_amount(10); lt.place()
r = lt.settle({c: 5 for c in settings.COLOR_ORDER})
check("no hits loses the bet", r["hits"] == 0 and r["payout"] == 0
      and not r["won"])
check("credits never go negative", lt.credits >= 0)
check("payout table", payout_for(0) == 0 and payout_for(1) == 2
      and payout_for(2) == 3 and payout_for(3) == 10)

random.seed(6)
hits_seen = {0:0, 1:0, 2:0, 3:0}
staked = returned = 0
for _ in range(60000):
    roll = [random.randint(1,6) for _ in range(3)]
    hits = sum(1 for d in roll if d == 4)
    hits_seen[hits] += 1
    staked += 10; returned += 10 * payout_for(hits)
print("  simulated: " + "  ".join("%d hits %.4f" % (k, v/60000)
                                  for k, v in sorted(hits_seen.items())))
check("stated chances match a 60k simulation",
      all(abs(hits_seen[k]/60000 - CHANCE[k]) < 0.01 for k in hits_seen))
print("  returned %.1f%% of everything staked (about 95%% is the design)"
      % (100 * returned / staked))
check("the booth keeps a small edge, not a big one",
      0.90 < returned / staked < 1.00)

print("\n--- BATTLE ROYALE ---")
b = BattleRoyale(4)
check("starts with 4 alive", len(b.alive)==4 and b.winner is None)
check("lowest roller found", b.lowest({"RED":5,"BLUE":2,"GREEN":6,"YELLOW":4})==["BLUE"])
b.knock_out("BLUE")
check("knocked out player leaves", "BLUE" not in b.alive and len(b.alive)==3)
check("no winner yet", b.winner is None)
b.knock_out("RED"); b.knock_out("YELLOW")
check("last one standing wins", b.winner=="GREEN")
check("placements", b.placement("GREEN")==1 and b.placement("BLUE")==4)
b.set_players(9); check("player count is capped at 6", b.player_count==6)
b.set_players(1); check("needs at least 2", b.player_count==2)
# play 200 whole battles
random.seed(8); lengths=[]
for _ in range(200):
    br = BattleRoyale(6); guard=0
    while not br.finished and guard < 60:
        guard += 1
        alive = br.begin_round()
        rolls = {c: random.randint(1,6) for c in alive}
        low = br.lowest(rolls)
        while len(low) > 1:                       # sudden death
            rerolls = {c: random.randint(1,6) for c in low}
            low = br.lowest(rerolls, low)
        br.knock_out(low[0])
    lengths.append(guard)
    assert br.finished, "a battle never produced a winner"
print("  200 six-player battles all finished; rounds needed: min %d max %d" %
      (min(lengths), max(lengths)))
check("every battle produced exactly one winner", max(lengths) < 60)

print("\n--- BEAT THE HOUSE ---")
hh = BeatTheHouse(200)
check("no amount is invalid", hh.validate()[0] is False)
hh.select_amount(50); hh.place(); check("stake taken", hh.credits==150)
check("starts with three dice each", hh.dice_count==3
      and len(hh.player_colors)==3 and len(hh.house_colors)==3)
r = hh.judge({"RED":6,"BLUE":6,"GREEN":6,"YELLOW":1,"PURPLE":1,"ORANGE":1})
check("player total", r["player_total"]==18)
check("house total", r["house_total"]==3)
check("player wins pays 2x", r["winner"]==PLAYER_A and hh.credits==250)
hh.select_amount(50); hh.place()
r = hh.judge({"RED":1,"BLUE":1,"GREEN":1,"YELLOW":6,"PURPLE":6,"ORANGE":6})
check("house wins pays nothing", r["winner"]==PLAYER_B and r["payout"]==0)
hh.select_amount(50); before = hh.credits; hh.place()
r = hh.judge({"RED":3,"BLUE":3,"GREEN":3,"YELLOW":3,"PURPLE":3,"ORANGE":3})
check("a draw returns the stake", r["winner"]==TIE and hh.credits==before)
check("score tracked", hh.player_wins==1 and hh.house_wins==1 and hh.draws==1)
# is it really fair?
random.seed(2); bank=0; stake=10; rounds=20000
for _ in range(rounds):
    res = {c: random.randint(1,6) for c in PLAYER_COLORS+HOUSE_COLORS}
    p = sum(res[c] for c in PLAYER_COLORS); ho = sum(res[c] for c in HOUSE_COLORS)
    bank += (2*stake if p>ho else stake if p==ho else 0) - stake
print("  20,000 rounds at 10 credits: player is %+d overall (should hover near 0)" % bank)
check("beat the house really is close to fair", abs(bank) < rounds*stake*0.03)

h2 = BeatTheHouse(100)
check("opens on the classic line-up so it is playable at once", h2.teams_ready)
h2.set_dice_count(1)
check("changing the dice count clears the picks",
      h2.dice_count==1 and h2.player_colors==[] and not h2.teams_ready)
h2.tap("PURPLE")
check("you can take any colour", h2.player_colors==["PURPLE"])
check("the machine is dealt in once you are full",
      h2.teams_ready and len(h2.house_colors)==1)
check("the machine never shares a colour with you",
      not set(h2.player_colors) & set(h2.house_colors))
check("the machine's colours cannot be taken", h2.tap(h2.house_colors[0]) is False)
h2.tap("PURPLE")
check("tapping your own colour gives it back", h2.player_colors==[])
check("with no dice picked the round cannot start",
      h2.teams_ready is False and h2.validate()[0] is False)
h2.set_dice_count(3); h2.randomise()
check("random deal keeps both sides equal and separate",
      len(h2.player_colors)==3 and len(h2.house_colors)==3
      and not set(h2.player_colors) & set(h2.house_colors))

print("\nRESULT:", "ALL PASS" if not fails else "FAILURES -> %s" % fails)
