"""
update_guide.py
---------------
Rebuilds the FULL INDEX section of CODE_GUIDE.txt straight from the code.

    python update_guide.py

Line numbers go stale the moment anyone edits a file, and a guide that sends
you to the wrong line is worse than no guide. Rather than fixing them by hand,
this reads every .py file and writes the index out fresh: every setting, every
constant, every class and every method, with the line it is actually on.

Run it whenever you have changed something and the numbers will be right
again. Then run check_guide.py to prove it.

Only the FULL INDEX section is replaced. Everything you wrote by hand above
and below it is left alone.
"""

import ast
import os

GUIDE = "CODE_GUIDE.txt"
# Sentinels marking the generated block. They are deliberately odd strings:
# the index lists every constant in the game, so an ordinary heading used as
# a marker would end up INSIDE the generated text and the script would then
# find its own output instead of the real end. That bug duplicated the whole
# index on every run until these sentinels replaced it.
START = "[INDEX-START]"
END = "[INDEX-END]"

# the order files are listed in, so the index reads sensibly rather than
# alphabetically: start point, settings, then rules, then drawing
# The two guide tools are left out on purpose: they are not part of the game,
# and indexing this file would put its own marker strings into the output.
FILE_ORDER = [
    "main.py",
    "config/settings.py",
    "game/game_manager.py",
    "game/cube.py",
    "game/dice.py",
    "game/physics.py",
    "game/layers.py",
    "game/tumbler.py",
    "game/betting.py",
    "game/over_under.py",
    "game/lucky_three.py",
    "game/beat_house.py",
    "game/battle.py",
    "game/duel.py",
    "game/consequences.py",
    "game/history.py",
    "game/audio.py",
    "ui/ui.py",
    "ui/scene.py",
    "ui/mode_screen.py",
    "ui/main_menu.py",
    "ui/color_royale_ui.py",
    "ui/over_under_ui.py",
    "ui/lucky_three_ui.py",
    "ui/beat_house_ui.py",
    "ui/consequence_ui.py",
    "ui/battle_royale_ui.py",
    "ui/duel_ui.py",
    "ui/settings_ui.py",
    "ui/result_ui.py",
    "ui/help_ui.py",
    "ui/particles.py",
]

# one-line notes so a reader knows why a file exists before reading its parts
FILE_NOTES = {
    "main.py": "starts pygame, makes the window, runs the game loop",
    "config/settings.py": "EVERY number and colour in the game. Start here.",
    "game/game_manager.py": "which screen is active, and switching between them",
    "game/cube.py": "the 3D dice maths: rotate, flatten, draw the visible faces",
    "game/dice.py": "the Die class: rolling, tumbling, settling, the result",
    "game/physics.py": "gravity, bouncing, friction, walls",
    "game/layers.py": "perspective and draw order - the 2.5D core",
    "game/tumbler.py": "the machine: walls, floor, glass, frame, equaliser",
    "game/betting.py": "Color Royale money rules. No drawing code.",
    "game/over_under.py": "Over/Under rules and counted odds. No drawing code.",
    "game/lucky_three.py": "Lucky Three rules and counted odds. No drawing code.",
    "game/beat_house.py": "Beat the House rules. No drawing code.",
    "game/battle.py": "Battle Royale elimination. No drawing code.",
    "game/duel.py": "Arcade Duel teams and scoring. No drawing code.",
    "game/consequences.py": "loads the dares, finds the lowest roll",
    "game/history.py": "the last-rounds strip and win/loss streaks",
    "game/audio.py": "sounds, made in memory when no .wav files exist",
    "ui/ui.py": "fonts, panels, buttons, gradients - the shared toolkit",
    "ui/scene.py": "the room: floor, ceiling, speakers, signs, reflection",
    "ui/mode_screen.py": "the shared skeleton all seven modes are built on",
    "ui/main_menu.py": "the menu and its floating dice",
    "ui/color_royale_ui.py": "COLOR ROYALE screen",
    "ui/over_under_ui.py": "OVER / UNDER screen",
    "ui/lucky_three_ui.py": "LUCKY THREE screen",
    "ui/beat_house_ui.py": "BEAT THE HOUSE screen",
    "ui/consequence_ui.py": "CONSEQUENCE POOL screen",
    "ui/battle_royale_ui.py": "BATTLE ROYALE screen",
    "ui/duel_ui.py": "ARCADE DUEL screen",
    "ui/settings_ui.py": "SETTINGS screen",
    "ui/result_ui.py": "the result card, shared by every mode",
    "ui/help_ui.py": "the HOW TO PLAY card, shared by every mode",
    "ui/particles.py": "the confetti burst on a win",
}


def short_value(node):
    """A readable version of what a constant is set to, kept short."""
    try:
        text = ast.unparse(node)
    except Exception:
        return ""
    text = " ".join(text.split())
    return text if len(text) <= 44 else text[:41] + "..."


def scan(path):
    """Return (constants, classes) found in one file, with line numbers."""
    source = open(path, encoding="utf-8").read()
    tree = ast.parse(source)

    constants = []
    classes = []
    functions = []

    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id.isupper():
                    constants.append((node.lineno, target.id, short_value(node.value)))
                # SPIN_MIN, SPIN_MAX = 260, 780
                elif isinstance(target, ast.Tuple):
                    for element in target.elts:
                        if isinstance(element, ast.Name) and element.id.isupper():
                            constants.append((node.lineno, element.id,
                                              short_value(node.value)))

        elif isinstance(node, ast.ClassDef):
            methods = []
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods.append((item.lineno, item.name))
                elif isinstance(item, ast.Assign):
                    for target in item.targets:
                        if isinstance(target, ast.Name) and target.id.isupper():
                            # written as the bare name, because that is what is
                            # actually on the line - the class is noted after it
                            constants.append((item.lineno, target.id,
                                              "%s   (in class %s)"
                                              % (short_value(item.value), node.name)))
            classes.append((node.lineno, node.name, methods))

        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions.append((node.lineno, node.name))

    return constants, classes, functions


def build():
    lines = [START, ""]
    lines += [
        "Every setting, constant, class and method in the game, with the line it",
        "is on. Use Ctrl+F for a name, or Ctrl+G in your editor to jump to a line.",
        "",
        "This section is GENERATED. Do not fix the numbers by hand - run",
        "update_guide.py and they are rebuilt from the code.",
        "",
    ]

    total_constants = total_methods = 0

    for path in FILE_ORDER:
        if not os.path.exists(path):
            continue

        constants, classes, functions = scan(path)
        note = FILE_NOTES.get(path, "")

        lines.append("")
        lines.append("-" * 74)
        lines.append(path.upper())
        if note:
            lines.append("    %s" % note)
        lines.append("")

        if constants:
            lines.append("  SETTINGS AND CONSTANTS")
            for number, name, value in constants:
                total_constants += 1
                text = "%s = %s" % (name, value) if value else name
                lines.append("    %s : %d   %s" % (path, number, text))
            lines.append("")

        if functions:
            lines.append("  FUNCTIONS")
            for number, name in functions:
                total_methods += 1
                lines.append("    %s : %d   def %s" % (path, number, name))
            lines.append("")

        for number, name, methods in classes:
            lines.append("  CLASS %s" % name)
            lines.append("    %s : %d   class %s" % (path, number, name))
            for method_line, method_name in methods:
                total_methods += 1
                lines.append("    %s : %d   def %s" % (path, method_line, method_name))
            lines.append("")

    lines.append("")
    lines.append("-" * 74)
    lines.append("INDEX TOTALS")
    lines.append("    %d settings and constants" % total_constants)
    lines.append("    %d functions and methods" % total_methods)
    lines.append("    across %d files" % len([p for p in FILE_ORDER if os.path.exists(p)]))
    lines.append("")
    lines.append(END)
    lines.append("")
    lines.append("")

    return "\n".join(lines)


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    if not os.path.exists(GUIDE):
        print("Could not find %s" % GUIDE)
        print()
        print("Looked in: %s" % os.getcwd())
        print()
        print("The file lives beside this script, in the same folder as")
        print("main.py. If it is not there, it was probably lost while")
        print("copying or extracting - take a fresh copy from the zip.")
        print()
        print("Files in this folder:")
        for name in sorted(os.listdir(".")):
            if not name.startswith("."):
                print("    %s" % name)
        raise SystemExit(1)

    guide = open(GUIDE, encoding="utf-8").read()

    if START not in guide or END not in guide:
        raise SystemExit("could not find the index markers in %s" % GUIDE)

    head = guide[:guide.index(START)]
    tail = guide[guide.index(END) + len(END):]
    open(GUIDE, "w", encoding="utf-8").write(head + build() + tail)
    print("FULL INDEX rebuilt in %s" % GUIDE)
    print("now run:  python check_guide.py")


if __name__ == "__main__":
    main()
