"""
diagnose_music.py
-----------------
Runs the REAL game audio setup, then tries to start the music, and prints
exactly what happens at each step. Run this to see why music is silent.

    python diagnose_music.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pygame
from config import settings
from game.audio import Audio

print("AUDIO_ENABLED in settings:", settings.AUDIO_ENABLED)
print("MUSIC_VOLUME  in settings:", settings.MUSIC_VOLUME)
print()

pygame.init()
audio = Audio()          # this is exactly what the game builds at startup

print("audio.enabled (sound card working):", audio.enabled)
print("audio.muted   (started muted?):     ", audio.muted)
print()

if not audio.enabled:
    print(">>> The game's mixer did not start. No sound at all is possible.")
    raise SystemExit()
if audio.muted:
    print(">>> Audio started MUTED. That is why there is no music.")
    print(">>> Check AUDIO_ENABLED = True in config/settings.py")
    raise SystemExit()

# find the file the game would use
found = None
for name in ("music.ogg","music.mp3","music.wav","background.ogg","background.mp3"):
    if os.path.exists(os.path.join(settings.SOUND_DIR, name)):
        found = name; break
print("music file the game will use:", found or "NONE FOUND")
if not found:
    raise SystemExit()

# now try to load it on the GAME'S mixer (not a fresh one) and REPORT errors
path = os.path.join(settings.SOUND_DIR, found)
print("game mixer settings:", pygame.mixer.get_init())
print()
try:
    pygame.mixer.music.load(path)
    pygame.mixer.music.set_volume(settings.MUSIC_VOLUME)
    pygame.mixer.music.play(-1)
    print(">>> LOADED AND PLAYING on the game's mixer.")
    print(">>> You should hear music now for 5 seconds...")
    pygame.time.wait(5000)
    print(">>> If you heard nothing, the file plays on a plain mixer but not")
    print(">>> the game's - convert it to .ogg, which is the most compatible.")
except pygame.error as e:
    print(">>> FAILED on the game's mixer, even though a plain test worked.")
    print(">>> Error:", e)
    print(">>> Fix: convert the track to .ogg and name it music.ogg")
