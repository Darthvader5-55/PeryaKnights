"""
Tests for the four newer modes: Over/Under, Higher or Lower, Battle Royale
and Beat the House.

    python tests_modes.py

Plays real rounds with the real buttons, and checks the dice you can see
always match the numbers the credits were worked out from. Also covers the
fairness fixes: no free cash-out in Higher or Lower, and Beat the House
scoring only the dice the player chose.
"""
import os, sys, random
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
sys.path.insert(0, os.getcwd())
import pygame
from config import settings
settings.SHOW_RULES_ON_ENTER = False   # drive the buttons directly
from game.game_manager import GameManager, GameState
pygame.init(); surf=pygame.display.set_mode((settings.SCREEN_WIDTH,settings.SCREEN_HEIGHT))
m=GameManager(surf)
DT=1/60
def click(b, settle=2):
    pygame.mouse.set_pos(b.rect.center)
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=b.rect.center))
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONUP,button=1,pos=b.rect.center))
    for _ in range(settle): m.update(DT); m.draw(surf)
def key(k):
    m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=k,unicode="")); step(2)
def step(n=1):
    for _ in range(n): m.update(DT); m.draw(surf)
def wait(cond, limit=1500, label=""):
    for i in range(limit):
        step()
        if cond(): return i
    raise AssertionError("TIMEOUT waiting for "+label)

random.seed(31)

# ================= OVER / UNDER : 30 rounds =================
m.change_state(GameState.OVER_UNDER); s=m.current_screen
from game.over_under import result_for, UNDER, OVER, EXACT
seen={UNDER:0,OVER:0,EXACT:0}; wins=0
for r in range(30):
    if not s.game.can_afford_anything(settings.BET_AMOUNTS): key(pygame.K_r)
    click(random.choice(s.choice_buttons))
    click([b for b in s.bet_buttons if int(b.label) <= s.game.credits][0])
    before = s.game.credits
    click(s.place_button)
    assert s.phase != "BETTING", "bet did not lock"
    assert s.game.credits == before - s.game.amount, "stake not deducted"
    wait(lambda: s.phase=="RESULT", 1500, "over/under result")
    res = s.game.last_result
    shown = {c: d.value for c,d in s.dice.by_color.items()}
    assert res["results"] == shown, "screen dice disagree with the result"
    assert res["total"] == sum(shown.values()), "total does not match the dice"
    assert res["landed"] == result_for(res["total"]), "wrong band"
    assert s.game.credits >= 0
    seen[res["landed"]] += 1; wins += res["won"]
    click(s.result_panel.primary)
print("OVER/UNDER   : 30 rounds ok, player won %d, bands seen %s" % (wins, seen))

# ================= LUCKY THREE : 30 rounds =================
m.change_state(GameState.LUCKY_THREE); s=m.current_screen
from game.lucky_three import TEAM_SIZE, PAYOUT
jackpots = 0; wins = 0
for r in range(30):
    if not s.game.can_afford_anything(settings.BET_AMOUNTS): key(pygame.K_r)
    click(s.random_button)
    assert len(s.game.colors) == TEAM_SIZE, "random did not pick three"
    click(random.choice(s.number_buttons))
    click([b for b in s.bet_buttons if int(b.label) <= s.game.credits][0])
    before = s.game.credits
    click(s.place_button)
    assert s.phase != "BETTING", "bet did not lock"
    assert s.game.credits == before - s.game.amount, "stake not deducted"
    wait(lambda: s.phase=="RESULT", 1500, "lucky three result")
    res = s.game.last_result
    shown = {c: d.value for c,d in s.dice.by_color.items()}
    assert res["results"] == shown, "screen dice disagree with the result"
    # the hits must be exactly the player's dice showing the player's number
    expected = [c for c in res["colors"] if shown[c] == res["number"]]
    assert res["hit_colors"] == expected, "hits counted wrong"
    assert res["hits"] == len(expected)
    assert res["payout"] == res["bet"] * PAYOUT.get(res["hits"], 0), "wrong payout"
    assert res["won"] == (res["hits"] > 0)
    assert s.game.credits >= 0
    wins += res["won"]; jackpots += res["jackpot"]
    click(s.result_panel.primary)
print("LUCKY THREE  : 30 rounds ok, won %d, jackpots %d, credits %d"
      % (wins, jackpots, s.game.credits))

# you can never hold more or fewer than three colours
cb = lambda n: next(b for b in s.color_buttons if b.label==n)
click(s.random_button)
for name in settings.COLOR_ORDER:
    click(cb(name))
    assert len(s.game.colors) <= TEAM_SIZE, "held more than three colours"
click(s.random_button)
assert len(s.game.colors) == TEAM_SIZE
print("LUCKY THREE  : never holds more than three colours")

# ================= BATTLE ROYALE : every player count =================
for count in range(2, 7):
    m.change_state(GameState.BATTLE_ROYALE); s=m.current_screen
    for b in s.count_buttons:
        if b.label == str(count): click(b)
    assert len(s.battle.alive) == count
    rounds = 0
    while not s.battle.finished and rounds < 20:
        if s.phase == "SETUP":
            click(s.roll_button); rounds += 1
        wait(lambda: s.phase in ("SETUP","FINISHED"), 2500, "battle round")
    assert s.battle.finished, "battle never finished with %d players" % count
    assert len(s.battle.alive)==1 and s.battle.winner == s.battle.alive[0]
    assert len(s.battle.knocked_out) == count-1
    visible = sorted(d.color_name for d in s.dice.dice if d.visible)
    print("BATTLE       : %d players -> winner %-6s in %d rounds (dice left on table: %d)"
          % (count, s.battle.winner, rounds, len(visible)))
    click(s.result_panel.primary)

# ================= BEAT THE HOUSE : 30 rounds =================
m.change_state(GameState.BEAT_HOUSE); s=m.current_screen

w=l=d=0
for r in range(30):
    if not s.game.can_afford_anything(settings.BET_AMOUNTS): key(pygame.K_r)
    click(s.random_button)                 # let it deal both sides
    click([b for b in s.bet_buttons if int(b.label) <= s.game.credits][0])
    click(s.roll_button)
    wait(lambda: s.phase=="RESULT", 1500, "beat the house result")
    res = s.game.last_result
    shown = {c: die.value for c,die in s.dice.by_color.items()}
    assert res["player_total"] == sum(shown[c] for c in res["player_colors"])
    assert res["house_total"] == sum(shown[c] for c in res["house_colors"])
    assert not set(res["player_colors"]) & set(res["house_colors"])
    assert s.game.credits >= 0
    w += res["winner"]=="A"; l += res["winner"]=="B"; d += res["winner"]=="TIE"
    click(s.result_panel.primary)
print("BEAT HOUSE   : 30 rounds ok, %dW %dL %dD, credits %d" % (w,l,d,s.game.credits))

# ================= navigation + spam =================
from game.game_manager import GameState as G
for st in (G.OVER_UNDER, G.LUCKY_THREE, G.BEAT_HOUSE, G.BATTLE_ROYALE):
    m.change_state(st); s=m.current_screen
    for _ in range(120):
        for b in s.buttons(): click(b, settle=0)
        step()
    assert m.state in (st, G.MAIN_MENU), "spam left a strange state: %s" % m.state
    m.change_state(G.MAIN_MENU); step(2)
print("SPAM         : all four survived 120 frames of clicking everything")

m.change_state(G.MAIN_MENU)
for i in range(len(m.current_screen.buttons) - 1):   # skip EXIT
    menu = m.current_screen
    click(menu.buttons[i]); step(3)
    m.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE)); step(3)
    assert m.state == G.MAIN_MENU, "ESC did not return from menu button %d" % i
print("NAVIGATION   : all 8 menu buttons open and ESC back out")

import time
for st in (G.OVER_UNDER, G.LUCKY_THREE, G.BEAT_HOUSE, G.BATTLE_ROYALE):
    m.change_state(st); step(10)
    t0=time.time(); step(120); el=time.time()-t0
    print("PERF         : %-14s %5.0f fps possible" % (st, 120/el))

print("\nNEW MODES: ALL CHECKS PASSED")

# ================= extra checks for the final build =================
print()
m.change_state(G.BATTLE_ROYALE); s=m.current_screen; step(3)
for b in s.count_buttons:
    if b.label=="4": click(b)
def click_at(pos):
    pygame.mouse.set_pos(pos)
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=pos))
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONUP,button=1,pos=pos))
    step(2)
def typekey(ch):
    m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_a,unicode=ch)); step(1)
click_at(s.name_rows["BLUE"].center)
for ch in "MIKE": typekey(ch)
m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_RETURN,unicode="")); step(2)
assert s.label_for("BLUE")=="MIKE", "name not saved: %s" % s.label_for("BLUE")
print("BATTLE NAMES : BLUE renamed to", s.label_for("MIKE" and "BLUE"))
click_at(s.name_rows["RED"].center)
for ch in "XX": typekey(ch)
m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_ESCAPE,unicode="")); step(2)
assert s.label_for("RED")=="RED", "escape should undo"
assert m.state==G.BATTLE_ROYALE, "escape while typing must not leave the mode"
print("BATTLE NAMES : escape cancels and stays in the mode")
# names must survive a whole battle and show in the result
while not s.battle.finished:
    if s.phase=="SETUP": click(s.roll_button)
    wait(lambda: s.phase in ("SETUP","FINISHED"), 2500, "battle")
assert s.label_for("BLUE")=="MIKE"
print("BATTLE NAMES : winner shown as", s.result_panel.big_note)

# beat the house lets you choose dice
m.change_state(G.BEAT_HOUSE); s=m.current_screen; step(3)
click(s.count_buttons[1])
assert s.game.dice_count==2 and s.game.player_colors==[]
cb = lambda n: next(b for b in s.color_buttons if b.label==n)
click(cb("PURPLE")); click(cb("ORANGE"))
assert s.game.player_colors==["PURPLE","ORANGE"], s.game.player_colors
assert len(s.game.house_colors)==2 and not set(s.game.house_colors)&{"PURPLE","ORANGE"}
assert not s.roll_button.enabled or s.game.amount is None
click(s.bet_buttons[0])
step(2); assert s.roll_button.enabled
visible = sorted(d.color_name for d in s.dice.dice if d.visible)
assert visible == sorted(s.game.in_play()), visible
print("BEAT HOUSE   : chose PURPLE+ORANGE, house got", s.game.house_colors,
      "- only 4 dice on the table")
click(s.roll_button); wait(lambda: s.phase=="RESULT", 1500, "beat house")
r = s.game.last_result
shown = {c: d.value for c,d in s.dice.by_color.items()}
assert r["player_total"]==sum(shown[c] for c in r["player_colors"])
print("BEAT HOUSE   : scored on the chosen dice only (%d vs %d)" %
      (r["player_total"], r["house_total"]))
print("\nFINAL EXTRAS: ALL CHECKS PASSED")
