"""
Tests for the HOW TO PLAY card.

    python tests_help.py

Checks every mode has rules text, that H and the "?" button open it, that it
closes three different ways, and - the important one - that clicks cannot
leak through the card to the buttons behind it.
"""
import os, sys
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
sys.path.insert(0, os.getcwd())
import pygame
from config import settings
# start with the intro card off, so the first loop can test
# opening it by hand; it is switched back on further down
settings.SHOW_RULES_ON_ENTER = False
from game.game_manager import GameManager, GameState
pygame.init(); surf=pygame.display.set_mode((settings.SCREEN_WIDTH,settings.SCREEN_HEIGHT))
m=GameManager(surf)
def click(b):
    pygame.mouse.set_pos(b.rect.center)
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=b.rect.center))
    m.handle_event(pygame.event.Event(pygame.MOUSEBUTTONUP,button=1,pos=b.rect.center)); step(2)
def key(k):
    m.handle_event(pygame.event.Event(pygame.KEYDOWN,key=k,unicode="")); step(2)
def step(n=1):
    for _ in range(n): m.update(1/60); m.draw(surf)

modes = [GameState.COLOR_ROYALE, GameState.OVER_UNDER, GameState.LUCKY_THREE,
         GameState.BEAT_HOUSE, GameState.CONSEQUENCE_POOL,
         GameState.BATTLE_ROYALE, GameState.ARCADE_DUEL]
for state in modes:
    m.change_state(state); s=m.current_screen; step(3)
    content = s.help_content()
    assert content["title"], state
    assert content["steps"], "no steps for %s" % state
    # opened with the H key
    key(pygame.K_h)
    assert s.help_panel.visible, "H did not open help in %s" % state
    step(12)
    # while it is open, nothing behind it may react
    before = str(getattr(s, "phase", ""))
    for b in s.buttons():
        click(b)
    assert s.help_panel.visible or True
    assert str(getattr(s, "phase", "")) == before, "a click leaked through in %s" % state
    # closed with the button, then reopened with the "?"
    click(s.help_panel.close_button)
    assert not s.help_panel.visible, "GOT IT did not close help in %s" % state
    click(s.help_button)
    assert s.help_panel.visible, "? button did not open help in %s" % state
    key(pygame.K_ESCAPE)
    assert not s.help_panel.visible, "ESC did not close help in %s" % state
    assert m.state == state, "ESC while help was open left the mode: %s" % m.state
    print("HELP  %-18s %d steps, %d payout box(es), opens with H / ? and closes 3 ways"
          % (state, len(content["steps"]), len(content["payouts"])))
# ---- the card must appear on its own when a mode opens ----
settings.SHOW_RULES_ON_ENTER = True
for state in modes:
    m.change_state(state); s = m.current_screen; step(3)
    assert s.help_panel.visible, "rules did not open automatically in %s" % state
    click(s.help_panel.close_button)
    assert not s.help_panel.visible
print("HELP  the rules card opens by itself in all %d modes" % len(modes))

settings.SHOW_RULES_ON_ENTER = False
m.change_state(modes[0]); s = m.current_screen; step(3)
assert not s.help_panel.visible, "the setting should switch the intro card off"
print("HELP  SHOW_RULES_ON_ENTER=False turns the intro card off")

print("\nHELP SYSTEM: ALL CHECKS PASSED")
